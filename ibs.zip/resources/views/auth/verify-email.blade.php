<!-- resources/views/auth/verify-email.blade.php -->
<x-guest-layout>
    <div class="flex flex-col items-center justify-center min-h-screen py-6 bg-gray-100">
        <div class="mb-4 text-sm text-gray-600 text-center">
            {{ __('Thanks for signing up! Please verify your email address by clicking on the link we just emailed to you.') }}
        </div>

        @if (session('status') == 'verification-link-sent')
            <div class="mb-4 font-medium text-sm text-green-600 text-center">
                {{ __('A new verification link has been sent to the email address you provided.') }}
            </div>
        @endif

        <div class="mt-4 flex items-center justify-center space-x-4">
            <form method="POST" action="{{ route('verification.send') }}">
                @csrf
                <div>
                    <x-primary-button>
                        {{ __('Resend Verification Email') }}
                    </x-primary-button>
                </div>
            </form>

            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit"
                    class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                    {{ __('Log Out') }}
                </button>
            </form>
        </div>
    </div>
</x-guest-layout>
