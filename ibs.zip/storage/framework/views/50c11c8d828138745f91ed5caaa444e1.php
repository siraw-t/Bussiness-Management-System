



<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 col-lg-2 bg-dark text-white sidebar position-fixed" style="height: 100vh; z-index: 1000;">
                <div class="position-sticky">
                    <h5 class="sidebar-title text-center mt-5">Employee Menu</h5>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link text-white" href="<?php echo e(route('leave-requests.index')); ?>">
                                <i class="bi bi-card-list"></i> Leave Requests
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="<?php echo e(route('payment-requests.index')); ?>">
                                <i class="bi bi-cash"></i> Payment Requests
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="<?php echo e(route('purchase-requests.index')); ?>">
                                <i class="bi bi-cart"></i> Purchase Requests
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="<?php echo e(route('weekly-plan.index')); ?>">
                                <i class="bi bi-calendar-week"></i> Weekly Plans
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="<?php echo e(route('weekly-reports.index')); ?>">
                                <i class="bi bi-file-earmark-text"></i> Weekly Reports
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="<?php echo e(route('stock_requisitions.index')); ?>">
                                <i class="bi bi-file-earmark-text"></i> Request Stock
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="col-md-10 offset-md-2 px-4">
                <h1 class="mb-4 text-center mt-5 animate__animated animate__fadeInDown"
                    style="color: #4A90E2; font-size: 2.5rem;">
                    <span>Employee</span> <span>Dashboard</span>
                </h1>
                <div class="text-center mb-4" style="width: 100%; max-width: 600px; margin: 0 auto;">
                    <div class="card text-bg-success shadow-lg animated-card"
                        style="animation: slideIn 0.5s ease forwards; background: #28a745; border: none;">
                        <div class="card-body">
                            <h5 class="card-title" style="color: white; font-weight: bold; display: inline-block;">
                                Welcome to <?php echo e(Auth::user()->company->company_name); ?>


                            </h5>
                            <button class="btn btn-light float-end" onclick="alert('Explore more!')"
                                style="transition: background-color 0.3s;">
                                <i class="fas fa-info-circle"></i> Info
                            </button>
                        </div>
                    </div>
                </div>

                <style>
                    /* Card Animation */
                    .animated-card {
                        animation-name: bounceIn;
                        animation-duration: 0.5s;
                    }

                    @keyframes bounceIn {
                        0% {
                            transform: scale(0);
                            opacity: 0;
                        }

                        50% {
                            transform: scale(1.05);
                        }

                        100% {
                            transform: scale(1);
                            opacity: 1;
                        }
                    }

                    .nav-link {
                        display: flex;
                        align-items: center;
                        padding: 10px 15px;
                        transition: background-color 0.3s ease, transform 0.3s ease;
                    }

                    .nav-link i {
                        margin-right: 10px;
                        transition: transform 0.3s ease;
                    }

                    .nav-link:hover {
                        background-color: rgba(255, 255, 255, 0.1);
                        transform: scale(1.02);
                    }

                    .nav-link:hover i {
                        transform: rotate(360deg);
                    }

                    /* Sidebar Toggle Button */
                    .sidebar-toggle {
                        display: none;
                        position: fixed;
                        top: 60px;
                        left: 15px;
                        z-index: 1100;
                    }

                    /* Mobile Styles */
                    @media (max-width: 768px) {
                        .sidebar-toggle {
                            display: block;
                        }

                        .sidebar {
                            position: absolute;
                            width: 250px;
                            height: 100vh;
                            left: -250px;
                            top: 30px;
                            transition: left 0.3s ease;
                            z-index: 1000;
                        }

                        .sidebar.show {
                            left: 0;
                        }

                        main {
                            margin-left: 0;
                        }
                    }
                </style>

                <!-- Sidebar Toggle Button for Mobile -->
                <button class="btn btn-primary sidebar-toggle" onclick="toggleSidebar()">
                    <i class="bi bi-list"></i>
                </button>

                <!-- Analytics Section -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h5>All Pending Requests Overview</h5>
                        <canvas id="pendingRequestsChart" class="chart"></canvas>
                    </div>
                    <div class="col-md-6">
                        <h5>Leave Requests Overview</h5>
                        <canvas id="leaveRequestsChart" class="chart"></canvas>
                    </div>
                    <div class="col-md-6">
                        <h5>Payment Requests Overview</h5>
                        <canvas id="paymentRequestsChart" class="chart"></canvas>
                    </div>
                    <div class="col-md-6">
                        <h5>Purchase Requests Overview</h5>
                        <canvas id="purchaseRequestsChart" class="chart"></canvas>
                    </div>
                    <div class="col-md-6">
                        <h5>Weekly Plans Overview</h5>
                        <canvas id="weeklyPlansChart" class="chart"></canvas>
                    </div>
                    <div class="col-md-6">
                        <h5>Weekly Reports Overview</h5>
                        <canvas id="weeklyReportsChart" class="chart"></canvas>
                    </div>
                    
                </div>

                <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                <script>
                    // Pending Requests Chart
                    const pendingRequestsData = {
                        labels: ['Leave Requests', 'Payment Requests', 'Purchase Requests', 'Weekly Plans', 'Weekly Reports'],
                        datasets: [{
                            label: 'Pending Requests',
                            data: [
                                <?php echo e($pendingCounts['leave_requests']); ?>,
                                <?php echo e($pendingCounts['payment_requests']); ?>,
                                <?php echo e($pendingCounts['purchase_requests']); ?>,
                                <?php echo e($pendingCounts['weekly_plans']); ?>,
                                <?php echo e($pendingCounts['weekly_reports']); ?>

                            ],
                            backgroundColor: [
                                'rgba(75, 192, 192, 0.8)',
                                'rgba(255, 99, 132, 0.8)',
                                'rgba(255, 206, 86, 0.8)',
                                'rgba(54, 162, 235, 0.8)',
                                'rgba(153, 102, 255, 0.8)'
                            ],
                            borderColor: 'rgba(0, 0, 0, 0.2)',
                            borderWidth: 1,
                        }]
                    };

                    // Prepare data for the charts
                    const leaveRequestsData = {
                        labels: ['Approved', 'Pending', 'Rejected'],
                        datasets: [{
                            label: 'Leave Requests',
                            data: [
                                <?php echo e($leaveCounts['approved'] ?? 0); ?>,
                                <?php echo e($leaveCounts['pending'] ?? 0); ?>,
                                <?php echo e($leaveCounts['rejected'] ?? 0); ?>

                            ],
                            backgroundColor: [
                                'rgba(75, 192, 192, 0.8)',
                                'rgba(255, 206, 86, 0.8)',
                                'rgba(255, 99, 132, 0.8)'
                            ],
                            borderColor: 'rgba(0, 0, 0, 0.2)',
                            borderWidth: 1,
                        }]
                    };

                    const paymentRequestsData = {
                        labels: ['Approved', 'Pending', 'Rejected'],
                        datasets: [{
                            label: 'Payment Requests',
                            data: [
                                <?php echo e($paymentCounts['approved'] ?? 0); ?>,
                                <?php echo e($paymentCounts['pending'] ?? 0); ?>,
                                <?php echo e($paymentCounts['rejected'] ?? 0); ?>

                            ],
                            backgroundColor: [
                                'rgba(153, 102, 255, 0.8)',
                                'rgba(255, 159, 64, 0.8)',
                                'rgba(255, 99, 132, 0.8)'
                            ],
                            borderColor: 'rgba(0, 0, 0, 0.2)',
                            borderWidth: 1,
                        }]
                    };

                    const purchaseRequestsData = {
                        labels: ['Approved', 'Pending', 'Rejected'],
                        datasets: [{
                            label: 'Purchase Requests',
                            data: [
                                <?php echo e($purchaseCounts['approved'] ?? 0); ?>,
                                <?php echo e($purchaseCounts['pending'] ?? 0); ?>,
                                <?php echo e($purchaseCounts['rejected'] ?? 0); ?>

                            ],
                            backgroundColor: [
                                'rgba(54, 162, 235, 0.8)',
                                'rgba(255, 206, 86, 0.8)',
                                'rgba(255, 99, 132, 0.8)'
                            ],
                            borderColor: 'rgba(0, 0, 0, 0.2)',
                            borderWidth: 1,
                        }]
                    };

                    const weeklyPlansData = {
                        labels: Object.keys(<?php echo json_encode($planCounts); ?>),
                        datasets: [{
                            label: 'Weekly Plans',
                            data: Object.values(<?php echo json_encode($planCounts); ?>),
                            backgroundColor: [
                                'rgba(75, 192, 192, 0.8)',
                            ],
                            borderColor: 'rgba(0, 0, 0, 0.2)',
                            borderWidth: 1,
                        }]
                    };

                    const weeklyReportsData = {
                        labels: Object.keys(<?php echo json_encode($reportCounts); ?>),
                        datasets: [{
                            label: 'Weekly Reports',
                            data: Object.values(<?php echo json_encode($reportCounts); ?>),
                            backgroundColor: [
                                'rgba(54, 162, 235, 0.8)',
                            ],
                            borderColor: 'rgba(0, 0, 0, 0.2)',
                            borderWidth: 1,
                        }]
                    };

                    // Create Charts
                    new Chart(document.getElementById('pendingRequestsChart').getContext('2d'), {
                        type: 'bar',
                        data: pendingRequestsData,
                    });

                    new Chart(document.getElementById('leaveRequestsChart').getContext('2d'), {
                        type: 'pie',
                        data: leaveRequestsData,
                    });

                    new Chart(document.getElementById('paymentRequestsChart').getContext('2d'), {
                        type: 'bar',
                        data: paymentRequestsData,
                    });

                    new Chart(document.getElementById('purchaseRequestsChart').getContext('2d'), {
                        type: 'bar',
                        data: purchaseRequestsData,
                    });

                    new Chart(document.getElementById('weeklyPlansChart').getContext('2d'), {
                        type: 'bar',
                        data: weeklyPlansData,
                    });

                    new Chart(document.getElementById('weeklyReportsChart').getContext('2d'), {
                        type: 'bar',
                        data: weeklyReportsData,
                    });

                    // Toggle sidebar function for mobile devices
                    function toggleSidebar() {
                        const sidebar = document.querySelector('.sidebar');
                        sidebar.classList.toggle('show');
                    }
                </script>

                <style>
                    .chart {
                        max-width: 100%;
                        height: auto;
                        cursor: pointer;
                        transition: transform 0.2s;
                    }

                    .chart:hover {
                        transform: scale(1.02);
                    }
                </style>
            </main>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/dashboards/employee.blade.php ENDPATH**/ ?>