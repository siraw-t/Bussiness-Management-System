

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="text-center text-primary mb-4">Edit Weekly Plan</h1>

        <form action="<?php echo e(route('weekly-plan.update', $weeklyPlan->plan_id)); ?>" method="POST"
            class="shadow p-4 rounded bg-light" style="max-width: 600px; margin: auto;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group mb-3">
                <label for="week">Week (YYYY-MM-DD)</label>
                <input type="date" name="week" class="form-control"
                    value="<?php echo e(\Carbon\Carbon::parse(old('week', $weeklyPlan->week))->format('Y-m-d')); ?>" required>
            </div>
            <div class="form-group mb-3">
                <label for="plan">Plan</label>
                <textarea name="plan" class="form-control" required><?php echo e(old('plan', $weeklyPlan->plan)); ?></textarea>
            </div>
            <div class="form-group mb-3">
                <label for="urgent_issues">Urgent Issues</label>
                <textarea name="urgent_issues" class="form-control"><?php echo e(old('urgent_issues', $weeklyPlan->urgent_issues)); ?></textarea>
            </div>
            <button type="submit" class="btn btn-success w-100">
                <i class="bi bi-check-lg"></i> Update
            </button>
            <a href="<?php echo e(route('weekly-plan.index')); ?>" class="btn btn-secondary w-100 mt-2">Cancel</a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/weekly-plan/edit.blade.php ENDPATH**/ ?>