

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="text-center text-success mb-4">Stock Requisitions</h1>

        

        <div class="text-center mb-4">
            <a href="<?php echo e(route('stock_requisitions.create')); ?>" class="btn btn-primary btn-sm">
                <i class="fas fa-plus-circle"></i> Create New Requisition
            </a>
        </div>

        <div class="table-responsive">
            <table class="table table-striped table-hover table-bordered mt-3">
                <thead class="thead-dark">
                    <tr>
                        <th>Reference Number</th>
                        <th>Item Name</th>
                        <th>Description</th>
                        <th>Quantity Requested</th>
                        <th>Unit Requested</th>
                        <th>Quantity Approved</th>
                        <th>Status</th>
                        <th>Requested By</th>
                        <th>Company Country</th>
                        <th>Manager Comment</th>
                        <th>Approved By</th>
                        <th>Employee Comment</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $requisitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requisition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($requisition->reference_number); ?></td>
                            <td><?php echo e($requisition->item_name); ?></td>
                            <td><?php echo e($requisition->description ?? 'N/A'); ?></td>
                            <td><?php echo e($requisition->quantity_requested); ?></td>
                            <td><?php echo e($requisition->unit_requested ?? 'N/A'); ?></td>
                            <td><?php echo e($requisition->quantity_approved ?? 'N/A'); ?></td>
                            <td><?php echo e(ucfirst($requisition->status)); ?></td>
                            <td>
                                <?php if($requisition->requested_by): ?>
                                    <?php echo e(optional(\App\Models\User::find($requisition->requested_by))->full_name ?? 'N/A'); ?>

                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($requisition->company_country); ?></td>
                            <td><?php echo e($requisition->manager_comment ?? 'N/A'); ?></td>
                            <td>
                                <?php
                                    $approver = \App\Models\User::find($requisition->approved_by);
                                ?>
                                <?php echo e(optional($approver)->full_name ?? 'N/A'); ?>

                            </td>
                            <td>
                                <form action="<?php echo e(route('stock_requisitions.comment', $requisition->stock_requisition_id)); ?>"
                                    method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" class="form-control" name="employee_comment" list="commentOptions"
                                        value="<?php echo e($requisition->employee_comment); ?>"
                                        <?php if($requisition->status !== 'approved'): ?> disabled <?php endif; ?>
                                        pattern="^(received|not_received)$"
                                        title="Please type 'received' or 'not_received' only." required>

                                    <datalist id="commentOptions">
                                        <option value="received">
                                        <option value="not_received">
                                    </datalist>

                                    <?php if($requisition->status !== 'approved'): ?>
                                        <small class="text-danger">Cannot change to "Received" until approved by
                                            manager.</small>
                                    <?php endif; ?>

                                    <button type="submit" class="btn btn-primary mt-2"
                                        <?php if($requisition->status !== 'approved'): ?> disabled <?php endif; ?>>
                                        Submit Comment
                                    </button>
                                </form>
                            </td>
                            <td>
                                <?php if($requisition->status === 'approved'): ?>
                                    <span class="btn btn-warning btn-sm disabled" title="Cannot edit approved requisitions">
                                        <i class="fas fa-edit"></i>
                                    </span>
                                <?php else: ?>
                                    <a href="<?php echo e(route('stock_requisitions.edit', $requisition->stock_requisition_id)); ?>"
                                        class="btn btn-warning btn-sm">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                <?php endif; ?>
                                <form
                                    action="<?php echo e(route('stock_requisitions.destroy', $requisition->stock_requisition_id)); ?>"
                                    method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm"
                                        onclick="return confirm('Are you sure you want to delete this requisition?');"
                                        <?php if($requisition->status === 'approved'): ?> disabled <?php endif; ?>>
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                                <a href="<?php echo e(route('stock_requisitions.downloadPdf', $requisition)); ?>"
                                    class="btn btn-info btn-sm">
                                    <i class="bi bi-file-earmark-pdf"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function updateEmployeeComment(requisitionId, commentValue) {
            fetch(`/stock_requisitions/${requisitionId}/updateComment`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                    body: JSON.stringify({
                        employee_comment: commentValue
                    })
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    alert('Employee comment updated successfully.');
                })
                .catch(error => {
                    console.error('There was a problem with the fetch operation:', error);
                });
        }
    </script>

    <style>
        @media (max-width: 375px) {
            .btn {
                font-size: 0.8rem;
                /* Smaller font size for mobile */
                padding: 0.4rem 0.6rem;
                /* Reduced padding */
            }

            .table th,
            .table td {
                font-size: 0.9rem;
                /* Smaller text for table */
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/stock_requisitions/index.blade.php ENDPATH**/ ?>