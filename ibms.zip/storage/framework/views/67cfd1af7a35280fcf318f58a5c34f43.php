

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="card shadow mx-auto" style="max-width: 600px;">
        <div class="card-header text-center bg-primary text-white">
            <h2><?php echo e($document->document_name); ?></h2>
        </div>
        <div class="card-body">
            <p class="lead"><strong>Type:</strong> <?php echo e($document->document_type); ?></p>
            <p class="lead"><strong>Description:</strong> <?php echo e($document->description); ?></p>
            <p class="lead"><strong>Owner:</strong> <?php echo e($document->owner->full_name); ?></p>
            <?php if($document->pdf_path): ?>
                <a href="<?php echo e(asset('storage/' . $document->pdf_path)); ?>" class="btn btn-success btn-lg mb-3" target="_blank">
                    <i class="bi bi-file-earmark-arrow-down"></i> Download PDF
                </a>
            <?php endif; ?>
            <br>
            <a href="<?php echo e(route('documents.index')); ?>" class="btn btn-success btn-lg">
                <i class="bi bi-arrow-left"></i> Back to Documents
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/documents/show.blade.php ENDPATH**/ ?>