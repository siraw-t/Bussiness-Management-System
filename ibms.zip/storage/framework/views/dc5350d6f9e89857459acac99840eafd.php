<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pending Requests</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .header {
            background-color: green;
            /* Bootstrap primary color */
            color: white;
            padding: 20px;
            text-align: center;
            border-radius: 0.5rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
            margin-top: 5px;
        }

        .no-requests {
            text-align: center;
            font-size: 1.1rem;
            color: #6c757d;
        }

        .action-buttons {
            text-align: center;
        }

        .table-container {
            margin-bottom: 40px;
        }

        .table th,
        .table td {
            vertical-align: middle;
        }

        .btn {
            padding: 10px;
            transition: background-color 0.3s, transform 0.2s;
        }

        .btn:hover {
            transform: scale(1.05);
        }

        .table-hover tbody tr:hover {
            background-color: #e9ecef;
            /* Light grey on hover */
        }
    </style>
</head>

<body>

    <div class="container mb-5">
        <h2 class="header text-center"> Pending Requests</h2>
        <a class="btn btn-outline-primary" href="<?php echo e(route('manager.dashboard')); ?>">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>

        

        <div class="table-container">
            <h5 class="text-primary mt-5">Pending Stock Requisition Requests</h5>
            <?php if($pendingStockRequisitionRequests->isEmpty()): ?>
                <p class="no-requests">No pending stock requisition requests at this time.</p>
            <?php else: ?>
                <table class="table table-striped table-hover">
                    <thead class="thead-dark">
                        <tr>
                            <th>Item Name</th>
                            <th>Description</th>
                            <th>Quantity Requested</th>
                            <th>Status</th>
                            <th>Requested By</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pendingStockRequisitionRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($request->item_name); ?></td>
                                <td><?php echo e($request->description ?? 'N/A'); ?></td>
                                <td><?php echo e($request->quantity_requested); ?> <?php echo e($request->unit_requested ?? 'N/A'); ?></td>
                                <td>
                                    <span class="badge bg-warning"><?php echo e(ucfirst($request->status)); ?></span>
                                </td>
                                <td><?php echo e(optional($request->user)->full_name ?? 'N/A'); ?></td>
                                <td class="action-buttons">
                                    <!-- Approve Button -->
                                    <button class="btn btn-success btn-sm" data-toggle="modal"
                                        data-target="#approveModal<?php echo e($request->stock_requisition_id); ?>">
                                        <i class="fas fa-check"></i> Approve
                                    </button>

                                    <!-- Reject Button -->
                                    <button class="btn btn-danger btn-sm" data-toggle="modal"
                                        data-target="#rejectModal<?php echo e($request->stock_requisition_id); ?>">
                                        <i class="fas fa-times"></i> Reject
                                    </button>
                                </td>
                            </tr>

                            <!-- Approval Modal -->
                            <div class="modal fade" id="approveModal<?php echo e($request->stock_requisition_id); ?>" tabindex="-1"
                                role="dialog" aria-labelledby="approveModalLabel<?php echo e($request->stock_requisition_id); ?>"
                                aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Approve Stock Requisition</h5>
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        </div>
                                        <form
                                            action="<?php echo e(route('manager.stock_requisition.approve', $request->stock_requisition_id)); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label
                                                        for="approved_quantity<?php echo e($request->stock_requisition_id); ?>">Approved
                                                        Quantity:</label>
                                                    <input type="number" class="form-control"
                                                        id="approved_quantity<?php echo e($request->stock_requisition_id); ?>"
                                                        name="approved_quantity" min="1"
                                                        max="<?php echo e($request->quantity_requested); ?>" required>
                                                </div>
                                                <div class="form-group">
                                                    <label
                                                        for="comment-approve<?php echo e($request->stock_requisition_id); ?>">Comments:</label>
                                                    <textarea class="form-control" id="comment-approve<?php echo e($request->stock_requisition_id); ?>" name="manager_comment"
                                                        rows="3" required></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-success">Approve</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Rejection Modal -->
                            <div class="modal fade" id="rejectModal<?php echo e($request->stock_requisition_id); ?>" tabindex="-1"
                                role="dialog" aria-labelledby="rejectModalLabel<?php echo e($request->stock_requisition_id); ?>"
                                aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Reject Stock Requisition</h5>
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        </div>
                                        <form
                                            action="<?php echo e(route('manager.stock_requisition.reject', $request->stock_requisition_id)); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label
                                                        for="comment-reject<?php echo e($request->stock_requisition_id); ?>">Comments:</label>
                                                    <textarea class="form-control" id="comment-reject<?php echo e($request->stock_requisition_id); ?>" name="manager_comment"
                                                        rows="3" required></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-danger">Reject</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>




        <!-- Pending Employee Plans -->
        <div class="table-container">
            <h5 class="text-primary mt-5">Pending Employee Plans</h5>
            <?php if($pendingEmployeePlans->isEmpty()): ?>
                <p class="no-requests">No pending employee plans at this time.</p>
            <?php else: ?>
                <table class="table table-striped table-hover">
                    <thead class="thead-dark">
                        <tr>
                            <th>Employee Name</th>
                            <th>Week</th>
                            <th>Plan</th>
                            <th>Submitted At</th>
                            <th>Urgent Issues</th>
                            <th>Status</th>
                            <th>Reference Number</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pendingEmployeePlans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($plan->employee->full_name ?? 'N/A'); ?></td>
                                <td><?php echo e($plan->week); ?></td>
                                <td><?php echo e($plan->plan); ?></td>
                                <td><?php echo e($plan->submitted_at->format('Y-m-d H:i:s')); ?></td>
                                <td><?php echo e($plan->urgent_issues ?? 'N/A'); ?></td>
                                <td>
                                    <span class="badge bg-warning"><?php echo e(ucfirst($plan->status)); ?></span>
                                </td>
                                <td><?php echo e($plan->reference_number); ?></td>
                                <td class="action-buttons">
                                    <!-- Approve Button -->
                                    <button class="btn btn-success btn-sm" data-toggle="modal"
                                        data-target="#approveModal<?php echo e($plan->plan_id); ?>">
                                        <i class="fas fa-check"></i> Approve
                                    </button>

                                    <!-- Reject Button -->
                                    <button class="btn btn-danger btn-sm" data-toggle="modal"
                                        data-target="#rejectModal<?php echo e($plan->plan_id); ?>">
                                        <i class="fas fa-times"></i> Reject
                                    </button>
                                </td>
                            </tr>

                            <!-- Approval Modal -->
                            <div class="modal fade" id="approveModal<?php echo e($plan->plan_id); ?>" tabindex="-1"
                                role="dialog" aria-labelledby="approveModalLabel<?php echo e($plan->plan_id); ?>"
                                aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Approve Employee Plan</h5>
                                            <button type="button" class="close"
                                                data-dismiss="modal">&times;</button>
                                        </div>
                                        <form action="<?php echo e(route('manager.plan.approve', $plan->plan_id)); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label for="manager-comments-approve<?php echo e($plan->plan_id); ?>">Manager
                                                        Comments:</label>
                                                    <textarea class="form-control" id="manager-comments-approve<?php echo e($plan->plan_id); ?>" name="manager_comments"
                                                        rows="3" required></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-success">Approve</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Rejection Modal -->
                            <div class="modal fade" id="rejectModal<?php echo e($plan->plan_id); ?>" tabindex="-1"
                                role="dialog" aria-labelledby="rejectModalLabel<?php echo e($plan->plan_id); ?>"
                                aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Reject Employee Plan</h5>
                                            <button type="button" class="close"
                                                data-dismiss="modal">&times;</button>
                                        </div>
                                        <form action="<?php echo e(route('manager.plan.reject', $plan->plan_id)); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label for="manager-comments-reject<?php echo e($plan->plan_id); ?>">Manager
                                                        Comments:</label>
                                                    <textarea class="form-control" id="manager-comments-reject<?php echo e($plan->plan_id); ?>" name="manager_comments"
                                                        rows="3" required></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-danger">Reject</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Pending Employee Reports -->
        <div class="table-container">
            <h5 class="text-primary mt-5">Pending Employee Reports</h5>
            <?php if($pendingEmployeeReports->isEmpty()): ?>
                <p class="no-requests">No pending employee reports at this time.</p>
            <?php else: ?>
                <table class="table table-striped table-hover">
                    <thead class="thead-dark">
                        <tr>
                            <th>Employee Name</th>
                            <th>Week</th>
                            <th>Last Week's Plan</th>
                            <th>Report</th>
                            <th>Submitted At</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pendingEmployeeReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $lastWeekPlan = \App\Models\EmployeePlan::where('employee_id', $report->employee_id)
                                    ->where('week', $report->week) // Fetch plan for the same week
                                    ->orderBy('week', 'desc')
                                    ->first();
                            ?>
                            <tr>
                                <td><?php echo e($report->employee->full_name ?? 'N/A'); ?></td>
                                <td><?php echo e($report->week); ?></td>
                                <td>
                                    <?php if($lastWeekPlan): ?>
                                        <?php echo e($lastWeekPlan->plan); ?>

                                    <?php else: ?>
                                        <span class="text-muted">No plan available</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($report->report); ?></td>
                                <td><?php echo e($report->submitted_at->format('Y-m-d H:i:s')); ?></td>
                                <td>
                                    <span class="badge bg-warning"><?php echo e(ucfirst($report->status)); ?></span>
                                </td>
                                <td class="action-buttons">
                                    <!-- Approve Button -->
                                    <button class="btn btn-success btn-sm" data-toggle="modal"
                                        data-target="#approveModal<?php echo e($report->report_id); ?>">
                                        <i class="fas fa-check"></i> Approve
                                    </button>

                                    <!-- Reject Button -->
                                    <button class="btn btn-danger btn-sm" data-toggle="modal"
                                        data-target="#rejectModal<?php echo e($report->report_id); ?>">
                                        <i class="fas fa-times"></i> Reject
                                    </button>
                                </td>
                            </tr>

                            <!-- Approval Modal -->
                            <div class="modal fade" id="approveModal<?php echo e($report->report_id); ?>" tabindex="-1"
                                role="dialog" aria-labelledby="approveModalLabel<?php echo e($report->report_id); ?>"
                                aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Approve Employee Report</h5>
                                            <button type="button" class="close"
                                                data-dismiss="modal">&times;</button>
                                        </div>
                                        <form action="<?php echo e(route('manager.report.approve', $report->report_id)); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label
                                                        for="manager-comments-approve<?php echo e($report->report_id); ?>">Manager
                                                        Comments:</label>
                                                    <textarea class="form-control" id="manager-comments-approve<?php echo e($report->report_id); ?>" name="manager_comments"
                                                        rows="3" required></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-success">Approve</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Rejection Modal -->
                            <div class="modal fade" id="rejectModal<?php echo e($report->report_id); ?>" tabindex="-1"
                                role="dialog" aria-labelledby="rejectModalLabel<?php echo e($report->report_id); ?>"
                                aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Reject Employee Report</h5>
                                            <button type="button" class="close"
                                                data-dismiss="modal">&times;</button>
                                        </div>
                                        <form action="<?php echo e(route('manager.report.reject', $report->report_id)); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label
                                                        for="manager-comments-reject<?php echo e($report->report_id); ?>">Manager
                                                        Comments:</label>
                                                    <textarea class="form-control" id="manager-comments-reject<?php echo e($report->report_id); ?>" name="manager_comments"
                                                        rows="3" required></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-danger">Reject</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Pending Leave Requests -->
        <div class="table-container">
            <h5 class="text-primary mt-5">Pending Leave Requests</h5>
            <?php if($pendingLeaveRequests->isEmpty()): ?>
                <p class="no-requests">No pending leave requests at this time.</p>
            <?php else: ?>
                <table class="table table-striped table-hover">
                    <thead class="thead-dark">
                        <tr>
                            <th>Leave Type</th>
                            <th>Other Reason</th>
                            <th>Requested By</th>
                            <th>Uploaded File</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Status</th>
                            <th>Company Country</th>
                            <th>Reference Number</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pendingLeaveRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(ucfirst(str_replace('_', ' ', $request->leave_type))); ?></td>
                                <td><?php echo e($request->other_reason ?? 'N/A'); ?></td>
                                <td><?php echo e($request->user->full_name); ?></td>
                                <td>
                                    <?php if($request->attachment): ?>
                                        <a href="<?php echo e(asset('storage/' . $request->attachment)); ?>" target="_blank">View
                                            File</a>
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($request->start_date); ?></td>
                                <td><?php echo e($request->end_date); ?></td>
                                <td>
                                    <span class="badge bg-warning"><?php echo e(ucfirst($request->status)); ?></span>
                                </td>
                                <td><?php echo e($request->company_country); ?></td>
                                <td><?php echo e($request->reference_number); ?></td>
                                <td class="action-buttons">
                                    <!-- Approve Button -->
                                    <button class="btn btn-success btn-sm" data-toggle="modal"
                                        data-target="#approveModal<?php echo e($request->leave_request_id); ?>">
                                        <i class="fas fa-check"></i> Approve
                                    </button>

                                    <!-- Reject Button -->
                                    <button class="btn btn-danger btn-sm" data-toggle="modal"
                                        data-target="#rejectModal<?php echo e($request->leave_request_id); ?>">
                                        <i class="fas fa-times"></i> Reject
                                    </button>
                                </td>
                            </tr>

                            <!-- Approval Modal -->
                            <div class="modal fade" id="approveModal<?php echo e($request->leave_request_id); ?>" tabindex="-1"
                                role="dialog" aria-labelledby="approveModalLabel<?php echo e($request->leave_request_id); ?>"
                                aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Approve Leave Request</h5>
                                            <button type="button" class="close"
                                                data-dismiss="modal">&times;</button>
                                        </div>
                                        <form
                                            action="<?php echo e(route('manager.leave.approve', ['leave_request_id' => $request->leave_request_id])); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label
                                                        for="manager-comments-approve<?php echo e($request->leave_request_id); ?>">Manager
                                                        Comments:</label>
                                                    <textarea class="form-control" id="manager-comments-approve<?php echo e($request->leave_request_id); ?>" name="manager_comments"
                                                        rows="3" required></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-success">Approve</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Rejection Modal -->
                            <div class="modal fade" id="rejectModal<?php echo e($request->leave_request_id); ?>" tabindex="-1"
                                role="dialog" aria-labelledby="rejectModalLabel<?php echo e($request->leave_request_id); ?>"
                                aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Reject Leave Request</h5>
                                            <button type="button" class="close"
                                                data-dismiss="modal">&times;</button>
                                        </div>
                                        <form
                                            action="<?php echo e(route('manager.leave.reject', ['leave_request_id' => $request->leave_request_id])); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label
                                                        for="manager-comments-reject<?php echo e($request->leave_request_id); ?>">Manager
                                                        Comments:</label>
                                                    <textarea class="form-control" id="manager-comments-reject<?php echo e($request->leave_request_id); ?>" name="manager_comments"
                                                        rows="3" required></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-danger">Reject</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Pending Purchase Requests -->
        <div class="table-container">
            <h5 class="text-primary">Pending Purchase Requests</h5>
            <?php if($pendingPurchaseRequests->isEmpty()): ?>
                <p class="no-requests">No pending purchase requests at this time.</p>
            <?php else: ?>
                <table class="table table-striped table-hover">
                    <thead class="thead-dark">
                        <tr>
                            <th>Reference Number</th>
                            <th>Item Name</th>
                            <th>Item Description</th>
                            <th>Quantity</th>
                            <th>Unit</th>
                            <th>Price</th>
                            <th>Total Price</th>
                            <th>Company Country</th>
                            <th>Requested By</th>
                            <th>Finance Comment</th>
                            <th>Checked By</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pendingPurchaseRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($request->reference_number); ?></td>
                                <td><?php echo e($request->item_name); ?></td>
                                <td><?php echo e($request->item_description ?? 'N/A'); ?></td>
                                <td><?php echo e($request->quantity); ?></td>
                                <td><?php echo e($request->unit); ?></td>
                                <td><?php echo e($request->price); ?> <?php echo e($request->currency); ?></td>
                                <td><?php echo e($request->total_price); ?> <?php echo e($request->currency); ?></td>
                                <td><?php echo e($request->company_country); ?></td>
                                <td><?php echo e($request->user->full_name); ?></td>
                                <td><?php echo e($request->finance_comment ?? 'N/A'); ?></td>
                                <td><?php echo e(optional(\App\Models\User::find($request->checked_by))->full_name ?? 'N/A'); ?>

                                </td>
                                <td>
                                    <span class="badge bg-warning"><?php echo e(ucfirst($request->status)); ?></span>
                                </td>
                                <td class="action-buttons">
                                    <?php if(empty($request->finance_comment)): ?>
                                        <button class="btn btn-success btn-sm" disabled
                                            title="Cannot approve - Missing finance verification">
                                            <i class="fas fa-check"></i> Approve
                                        </button>
                                        <button class="btn btn-danger btn-sm" disabled
                                            title="Cannot reject - Missing finance verification">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    <?php else: ?>
                                        <button class="btn btn-success btn-sm" data-toggle="modal"
                                            data-target="#approveModal<?php echo e($request->purchase_request_id); ?>">
                                            <i class="fas fa-check"></i> Approve
                                        </button>
                                        <button class="btn btn-danger btn-sm" data-toggle="modal"
                                            data-target="#rejectModal<?php echo e($request->purchase_request_id); ?>">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>

                            <!-- Approval Modal -->
                            <div class="modal fade" id="approveModal<?php echo e($request->purchase_request_id); ?>"
                                tabindex="-1" role="dialog">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Approve Purchase Request</h5>
                                            <button type="button" class="close"
                                                data-dismiss="modal">&times;</button>
                                        </div>
                                        <form
                                            action="<?php echo e(route('manager.purchase.approve', ['purchase_request_id' => $request->purchase_request_id])); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label
                                                        for="manager-comment-approve<?php echo e($request->purchase_request_id); ?>">Manager
                                                        Comments:</label>
                                                    <textarea class="form-control" id="manager-comment-approve<?php echo e($request->purchase_request_id); ?>"
                                                        name="manager_comment" rows="3" required></textarea>
                                                </div>
                                                <div>
                                                    <strong>Attachments:</strong>
                                                    <ul>
                                                        <?php $__currentLoopData = json_decode($request->attachments, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li><a href="<?php echo e(asset($attachment)); ?>"
                                                                    target="_blank"><?php echo e(basename($attachment)); ?></a>
                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-success">Approve</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Rejection Modal -->
                            <div class="modal fade" id="rejectModal<?php echo e($request->purchase_request_id); ?>"
                                tabindex="-1" role="dialog">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Reject Purchase Request</h5>
                                            <button type="button" class="close"
                                                data-dismiss="modal">&times;</button>
                                        </div>
                                        <form
                                            action="<?php echo e(route('manager.purchase.reject', ['purchase_request_id' => $request->purchase_request_id])); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label
                                                        for="manager-comment-reject<?php echo e($request->purchase_request_id); ?>">Manager
                                                        Comments:</label>
                                                    <textarea class="form-control" id="manager-comment-reject<?php echo e($request->purchase_request_id); ?>"
                                                        name="manager_comment" rows="3" required></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-danger">Reject</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Pending Payment Requests -->
        <div class="table-container">
            <h5 class="text-primary">Pending Payment Requests</h5>
            <?php if($pendingPaymentRequests->isEmpty()): ?>
                <p class="no-requests">No pending payment requests at this time.</p>
            <?php else: ?>
                <table class="table table-striped table-hover">
                    <thead class="thead-dark">
                        <tr>
                            
                            <th>Request Date</th>
                            <th>Department</th>
                            <th>Finance Comment</th>
                            
                            <th>Item Name</th>
                            <th>Quantity</th>
                            <th>Amount</th>
                            <th>VAT</th>
                            <th>Total</th>
                            <th>Net Payment</th>
                            <th>Withholding</th>
                            <th>Status</th>
                            <th>Manager Comment</th>
                            <th>Checked By</th>
                            
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pendingPaymentRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                
                                <td><?php echo e($request->request_date ? $request->request_date->format('Y-m-d') : 'N/A'); ?>

                                </td>
                                <td><?php echo e($request->department ?? 'N/A'); ?></td>
                                <td><?php echo e($request->finance_comment ?? 'N/A'); ?></td>
                                
                                <td><?php echo e($request->item_name ?? 'N/A'); ?></td>
                                <td><?php echo e($request->quantity ?? 'N/A'); ?> <?php echo e($request->unit ?? 'N/A'); ?></td>
                                <td><?php echo e(number_format($request->amount, 2)); ?> <?php echo e($request->currency ?? 'N/A'); ?></td>
                                <td><?php echo e(number_format($request->vat, 2) ?? '0.00'); ?>

                                    <?php echo e($request->currency ?? 'N/A'); ?>

                                </td>
                                <td><?php echo e(number_format($request->total, 2)); ?> <?php echo e($request->currency ?? 'N/A'); ?></td>
                                <td><?php echo e(number_format($request->net_payment, 2)); ?> <?php echo e($request->currency ?? 'N/A'); ?>

                                </td>
                                <td><?php echo e(number_format($request->with_holding, 2) ?? '0.00'); ?>

                                    <?php echo e($request->currency ?? 'N/A'); ?></td>
                                <td>
                                    <span
                                        class="badge <?php echo e($request->status === 'approved' ? 'bg-success' : ($request->status === 'pending' ? 'bg-warning' : 'bg-danger')); ?>">
                                        <?php echo e(ucfirst($request->status)); ?>

                                    </span>
                                </td>
                                <td><?php echo e($request->manager_comment ?? 'N/A'); ?></td>
                                <td><?php echo e($request->reviewed_by ? optional(\App\Models\User::find($request->reviewed_by))->full_name : 'Not Checked'); ?>

                                </td>
                                
                                <td class="action-buttons">
                                    <?php if(empty($request->finance_comment)): ?>
                                        <button class="btn btn-success btn-sm" disabled
                                            title="Cannot approve - Missing finance verification">
                                            <i class="fas fa-check"></i> Approve
                                        </button>
                                        <button class="btn btn-danger btn-sm" disabled
                                            title="Cannot reject - Missing finance verification">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    <?php else: ?>
                                        <button class="btn btn-success btn-sm" data-toggle="modal"
                                            data-target="#approveModal<?php echo e($request->payment_request_id); ?>">
                                            <i class="fas fa-check"></i> Approve
                                        </button>
                                        <button class="btn btn-danger btn-sm" data-toggle="modal"
                                            data-target="#rejectModal<?php echo e($request->payment_request_id); ?>">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>

                            <!-- Approval Modal -->
                            <div class="modal fade" id="approveModal<?php echo e($request->payment_request_id); ?>"
                                tabindex="-1" role="dialog">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Approve Payment Request</h5>
                                            <button type="button" class="close"
                                                data-dismiss="modal">&times;</button>
                                        </div>
                                        <form
                                            action="<?php echo e(route('manager.payment.approve', ['payment_request_id' => $request->payment_request_id])); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label
                                                        for="manager-comment-approve<?php echo e($request->payment_request_id); ?>">Manager
                                                        Comments:</label>
                                                    <textarea class="form-control" id="manager-comment-approve<?php echo e($request->payment_request_id); ?>"
                                                        name="manager_comment" rows="3" required></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-success">Approve</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Rejection Modal -->
                            <div class="modal fade" id="rejectModal<?php echo e($request->payment_request_id); ?>"
                                tabindex="-1" role="dialog">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Reject Payment Request</h5>
                                            <button type="button" class="close"
                                                data-dismiss="modal">&times;</button>
                                        </div>
                                        <form
                                            action="<?php echo e(route('manager.payment.reject', ['payment_request_id' => $request->payment_request_id])); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label
                                                        for="manager-comment-reject<?php echo e($request->payment_request_id); ?>">Manager
                                                        Comments:</label>
                                                    <textarea class="form-control" id="manager-comment-reject<?php echo e($request->payment_request_id); ?>" name="manager_comment"
                                                        rows="3" required></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-danger">Reject</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Pending Payrolls -->
        <div class="table-container">
            <h5 class="text-primary">Pending Payrolls</h5>
            <?php if($pendingPayrolls->isEmpty()): ?>
                <p class="no-requests">No pending payrolls at this time.</p>
            <?php else: ?>
                <table class="table table-striped table-hover">
                    <thead class="thead-dark">
                        <tr>
                            <th>Employee</th>
                            <th>Job Title</th>
                            <th>Pay Period</th>
                            <th>Basic Salary</th>
                            <th>Transport Allowance</th>
                            <th>Taxable Transport Allowance</th>
                            <th>Position Allowance</th>
                            <th>Total Taxable Earnings</th>
                            <th>Income Tax</th>
                            <th>Pension Fund 7%</th>
                            <th>Pension Fund 11%</th>
                            <th>Salary Advance</th>
                            <th>Net Salary</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pendingPayrolls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payroll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($payroll->employee->full_name); ?></td>
                                <td><?php echo e($payroll->job_title); ?></td>
                                <td><?php echo e($payroll->pay_period); ?></td>
                                <td><?php echo e(number_format($payroll->basic_salary, 2)); ?> <?php echo e($payroll->currency); ?></td>
                                <td><?php echo e(number_format($payroll->transport_allowance ?? 0, 2)); ?>

                                    <?php echo e($payroll->currency); ?></td>
                                <td><?php echo e(number_format($payroll->taxable_transport_allowance ?? 0, 2)); ?>

                                    <?php echo e($payroll->currency); ?></td>
                                <td><?php echo e(number_format($payroll->position_allowance ?? 0, 2)); ?>

                                    <?php echo e($payroll->currency); ?></td>
                                <td><?php echo e(number_format($payroll->total_taxable_earnings, 2)); ?>

                                    <?php echo e($payroll->currency); ?></td>
                                <td><?php echo e(number_format($payroll->income_tax, 2)); ?> <?php echo e($payroll->currency); ?></td>
                                <td><?php echo e(number_format($payroll->pension_fund_7, 2)); ?> <?php echo e($payroll->currency); ?></td>
                                <td><?php echo e(number_format($payroll->pension_fund_11, 2)); ?> <?php echo e($payroll->currency); ?></td>
                                <td><?php echo e(number_format($payroll->salary_advance ?? 0, 2)); ?> <?php echo e($payroll->currency); ?>

                                </td>
                                <td><?php echo e(number_format($payroll->net_payment, 2)); ?> <?php echo e($payroll->currency); ?></td>
                                <td><?php echo e(ucfirst($payroll->status)); ?></td>
                                <td class="action-buttons">
                                    <!-- Approve Button -->
                                    <button class="btn btn-success btn-sm" data-toggle="modal"
                                        data-target="#approveModal<?php echo e($payroll->payroll_id); ?>">
                                        <i class="fas fa-check"></i> Approve
                                    </button>

                                    <!-- Reject Button -->
                                    <button class="btn btn-danger btn-sm" data-toggle="modal"
                                        data-target="#rejectModal<?php echo e($payroll->payroll_id); ?>">
                                        <i class="fas fa-times"></i> Reject
                                    </button>
                                </td>
                            </tr>

                            <!-- Approval Modal -->
                            <div class="modal fade" id="approveModal<?php echo e($payroll->payroll_id); ?>" tabindex="-1"
                                role="dialog" aria-labelledby="approveModalLabel<?php echo e($payroll->payroll_id); ?>"
                                aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Approve Payroll</h5>
                                            <button type="button" class="close"
                                                data-dismiss="modal">&times;</button>
                                        </div>
                                        <form
                                            action="<?php echo e(route('manager.payroll.approve', ['payroll_id' => $payroll->payroll_id])); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label
                                                        for="manager-comments-approve<?php echo e($payroll->payroll_id); ?>">Manager
                                                        Comments</label>
                                                    <textarea class="form-control" id="manager-comments-approve<?php echo e($payroll->payroll_id); ?>" name="manager_comment"
                                                        rows="3" required></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-success">Approve</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Rejection Modal -->
                            <div class="modal fade" id="rejectModal<?php echo e($payroll->payroll_id); ?>" tabindex="-1"
                                role="dialog" aria-labelledby="rejectModalLabel<?php echo e($payroll->payroll_id); ?>"
                                aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Reject Payroll</h5>
                                            <button type="button" class="close"
                                                data-dismiss="modal">&times;</button>
                                        </div>
                                        <form
                                            action="<?php echo e(route('manager.payroll.reject', ['payroll_id' => $payroll->payroll_id])); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label
                                                        for="manager-comments-reject<?php echo e($payroll->payroll_id); ?>">Manager
                                                        Comments</label>
                                                    <textarea class="form-control" id="manager-comments-reject<?php echo e($payroll->payroll_id); ?>" name="manager_comment"
                                                        rows="3" required></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-danger">Reject</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Pending Budget Forecasts -->
        <div class="table-container">
            <h5 class="text-primary">Pending Budget Forecasts</h5>
            <?php if($pendingBudgetForecasts->isEmpty()): ?>
                <p class="no-requests">No pending budget forecasts at this time.</p>
            <?php else: ?>
                <table class="table table-striped table-hover">
                    <thead class="thead-dark">
                        <tr>
                            <th>Forecast Period</th>
                            <th>Budget Description</th>
                            <th>Department</th>
                            <th>Budget Source</th>
                            <th>Quantity</th>
                            <th>Unit Cost</th>
                            <th>Total Budget</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pendingBudgetForecasts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forecast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(ucfirst($forecast->forecast_period)); ?></td>
                                <td><?php echo e($forecast->budget_description); ?></td>
                                <td><?php echo e($forecast->department); ?></td>
                                <td><?php echo e($forecast->budget_source); ?></td>
                                <td><?php echo e($forecast->quantity); ?> <?php echo e($forecast->unit); ?></td>
                                <td><?php echo e(number_format($forecast->unit_cost, 2)); ?> <?php echo e($forecast->currency); ?></td>
                                <td><?php echo e(number_format($forecast->total_budget, 2)); ?> <?php echo e($forecast->currency); ?></td>
                                <td class="action-buttons">
                                    <!-- Approve Button -->
                                    <button class="btn btn-success btn-sm" data-toggle="modal"
                                        data-target="#approveModal<?php echo e($forecast->budget_id); ?>">
                                        <i class="fas fa-check"></i> Approve
                                    </button>

                                    <!-- Reject Button -->
                                    <button class="btn btn-danger btn-sm" data-toggle="modal"
                                        data-target="#rejectModal<?php echo e($forecast->budget_id); ?>">
                                        <i class="fas fa-times"></i> Reject
                                    </button>
                                </td>
                            </tr>

                            <!-- Approval Modal -->
                            <div class="modal fade" id="approveModal<?php echo e($forecast->budget_id); ?>" tabindex="-1"
                                role="dialog" aria-labelledby="approveModalLabel<?php echo e($forecast->budget_id); ?>"
                                aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Approve Budget</h5>
                                            <button type="button" class="close"
                                                data-dismiss="modal">&times;</button>
                                        </div>
                                        <form
                                            action="<?php echo e(route('manager.budget.approve', ['budget_id' => $forecast->budget_id])); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label
                                                        for="manager-comments-approve<?php echo e($forecast->budget_id); ?>">Manager
                                                        Comments</label>
                                                    <textarea class="form-control" id="manager-comments-approve<?php echo e($forecast->budget_id); ?>" name="manager_comment"
                                                        rows="3" required></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-success">Approve</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Rejection Modal -->
                            <div class="modal fade" id="rejectModal<?php echo e($forecast->budget_id); ?>" tabindex="-1"
                                role="dialog" aria-labelledby="rejectModalLabel<?php echo e($forecast->budget_id); ?>"
                                aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Reject Budget</h5>
                                            <button type="button" class="close"
                                                data-dismiss="modal">&times;</button>
                                        </div>
                                        <form
                                            action="<?php echo e(route('manager.budget.reject', ['budget_id' => $forecast->budget_id])); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label
                                                        for="manager-comments-reject<?php echo e($forecast->budget_id); ?>">Manager
                                                        Comments</label>
                                                    <textarea class="form-control" id="manager-comments-reject<?php echo e($forecast->budget_id); ?>" name="manager_comment"
                                                        rows="3" required></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-danger">Reject</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>





        <!-- Optional: Add Bootstrap Icons -->

        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <script>
            $(function() {
                $('[data-toggle="tooltip"]').tooltip();
            });
        </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/display/pending.blade.php ENDPATH**/ ?>