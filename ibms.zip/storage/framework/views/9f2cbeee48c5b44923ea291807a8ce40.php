

<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-5">
        <h2 class="text-center text-primary mb-4"><?php echo e(Auth::user()->company->company_name); ?> Employee Reports</h2>

        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover">
                <thead class="thead-dark">
                    <tr>
                        <th>Full Name</th>
                        <th>Week</th>
                        <th>Last Week's Plan</th>
                        <th>Report</th>
                        <th>Tasks In Progress</th>
                        <th>Tasks Completed</th>
                        <th>Self Assessment</th>
                        <th>Submitted At</th>
                        <th>Manager Comment</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($employeeReports->isEmpty()): ?>
                        <tr>
                            <td colspan="10" class="text-center">No reports found.</td>
                        </tr>
                    <?php else: ?>
                        <?php $__currentLoopData = $employeeReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $lastWeekPlan = \App\Models\EmployeePlan::where('employee_id', $report->employee_id)
                                    ->where('week', $report->week) // Fetch plan for the same week
                                    ->orderBy('week', 'desc')
                                    ->first();
                            ?>
                            <tr class="align-middle" style="transition: background-color 0.3s;">
                                <td><?php echo e($report->employee->full_name ?? 'N/A'); ?></td>
                                <td><?php echo e($report->week); ?></td>
                                <td>
                                    <?php if($lastWeekPlan): ?>
                                        <?php echo e($lastWeekPlan->plan); ?>

                                    <?php else: ?>
                                        <span class="text-muted">No plan available</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($report->report); ?></td>
                                <td><?php echo e($report->tasks_in_progress ?? 'N/A'); ?></td>
                                <td><?php echo e($report->tasks_completed ?? 'N/A'); ?></td>
                                <td><?php echo e($report->self_assessment ?? 'N/A'); ?></td>
                                <td><?php echo e($report->submitted_at->format('Y-m-d H:i:s')); ?></td>
                                <td><?php echo e($report->manager_comment ?? 'N/A'); ?></td>
                                <td>
                                    <span
                                        class="badge <?php echo e($report->status == 'approved' ? 'bg-success' : ($report->status == 'rejected' ? 'bg-danger' : 'bg-warning')); ?>">
                                        <?php echo e(ucfirst($report->status)); ?>

                                    </span>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('weekly-reports.downloadPdf', $report)); ?>"
                                        class="btn btn-info btn-sm">
                                        <i class="bi bi-download"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

    <style>
        .table-hover tr:hover {
            background-color: #f8f9fa;
            /* Light grey on hover */
            cursor: pointer;
            /* Pointer cursor on hover */
            transition: background-color 0.3s;
            /* Smooth transition */
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/display/report.blade.php ENDPATH**/ ?>