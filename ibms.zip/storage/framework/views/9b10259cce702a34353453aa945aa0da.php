

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="text-center text-primary mb-4">Create Stock Requisition</h1>

        <form action="<?php echo e(route('stock_requisitions.store')); ?>" method="POST" class="shadow p-4 rounded bg-light"
            style="max-width: 500px; margin: auto;">
            <?php echo csrf_field(); ?>
            <div class="form-group mb-3">
                <label for="item_name">Item Name</label>
                <select name="item_name" class="form-control" required>
                    <option value="" disabled selected>Select an item</option>
                    <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($inventory->item_name); ?>"><?php echo e($inventory->item_name); ?> -
                            <?php echo e($inventory->description); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group mb-3">
                <label for="description">Description</label>
                <textarea name="description" class="form-control" rows="3" placeholder="Optional"></textarea>
            </div>

            <div class="form-group mb-3">
                <label for="quantity_requested">Quantity Requested</label>
                <input type="number" name="quantity_requested" class="form-control" required min="1">
            </div>

            <div class="form-group mb-3">
                <label for="unit_requested">Unit Requested</label>
                <input type="text" name="unit_requested" class="form-control" placeholder="e.g., pcs, kg">
            </div>

            <button type="submit" class="btn btn-primary w-100">
                <i class="fas fa-plus-circle"></i> Submit Requisition
            </button>
            <a href="<?php echo e(route('stock_requisitions.index')); ?>" class="btn btn-secondary w-100 mt-2">
                <i class="fas fa-times-circle"></i> Cancel
            </a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/stock_requisitions/create.blade.php ENDPATH**/ ?>