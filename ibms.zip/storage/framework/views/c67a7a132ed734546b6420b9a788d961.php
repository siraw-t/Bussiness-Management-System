

<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-5">
        <h2 class="text-center text-info mb-4"><?php echo e(Auth::check() ? Auth::user()->company->company_name : 'Company'); ?> Purchase
            Requests</h2>

        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover">
                <thead class="thead-dark">
                    <tr>
                        <th>Reference Number</th>
                        <th>Item Name</th>
                        <th>Item Description</th>
                        <th>Quantity</th>
                        <th>Unit</th>
                        <th>Price</th>
                        <th>Total Price</th>
                        <th>Status</th>
                        <th>Finance Comment</th>
                        <th>Manager Comment</th>
                        <th>Checked By</th>
                        <th>Approved By</th>
                        <th>Company Country</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        // Check if the user is authenticated
                        $companyId = Auth::check() ? auth()->user()->company_id : null;

                        // Filter purchase requests to show only those from the user's company
                        $filteredPurchaseRequests = $purchaseRequests->filter(function ($request) use ($companyId) {
                            return $request->user && $request->user->company_id == $companyId;
                        });
                    ?>

                    <?php if($filteredPurchaseRequests->isEmpty()): ?>
                        <tr>
                            <td colspan="16" class="text-center">No purchase requests found.</td>
                        </tr>
                    <?php else: ?>
                        <?php $__currentLoopData = $filteredPurchaseRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="align-middle" style="transition: background-color 0.3s;">
                                <td><?php echo e($request->reference_number); ?></td>
                                <td><?php echo e($request->item_name); ?></td>
                                <td><?php echo e($request->item_description ?? 'N/A'); ?></td>
                                <td><?php echo e($request->quantity); ?> <?php echo e($request->unit); ?></td>
                                <td><?php echo e($request->unit); ?></td>
                                <td><?php echo e($request->price); ?> <?php echo e($request->currency); ?></td>
                                <td><?php echo e($request->total_price); ?> <?php echo e($request->currency); ?></td>
                                <td>
                                    <span
                                        class="badge 
                                        <?php echo e($request->status === 'approved' ? 'bg-success' : ($request->status === 'pending' ? 'bg-warning' : 'bg-danger')); ?>">
                                        <?php echo e(ucfirst($request->status)); ?>

                                    </span>
                                </td>
                                <td><?php echo e($request->finance_comment ?? 'N/A'); ?></td>
                                <td><?php echo e($request->manager_comment ?? 'N/A'); ?></td>
                                <td><?php echo e(optional(\App\Models\User::find($request->checked_by))->full_name ?? 'N/A'); ?></td>
                                <td><?php echo e(optional(\App\Models\User::find($request->approved_by))->full_name ?? 'N/A'); ?></td>
                                <td><?php echo e($request->company_country); ?></td>
                                <td><?php echo e($request->created_at->format('Y-m-d H:i:s')); ?></td>
                                <td><?php echo e($request->updated_at->format('Y-m-d H:i:s')); ?></td>
                                <td>
                                    <a href="<?php echo e(route('purchase-requests.downloadPdf', $request)); ?>" class="btn btn-info">
                                        <i class="bi bi-download"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Optional: Add Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

    <!-- Custom CSS for hover effects -->
    <style>
        .table-hover tr:hover {
            background-color: #f8f9fa;
            /* Light grey on hover */
            cursor: pointer;
            /* Pointer cursor on hover */
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/display/purchase.blade.php ENDPATH**/ ?>