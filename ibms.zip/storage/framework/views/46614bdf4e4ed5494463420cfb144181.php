

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Create Request Form Template</h1>
        <form action="<?php echo e(route('templates.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="form_name" class="form-label">Form Name</label>
                <input type="text" name="form_name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="fields" class="form-label">Fields (JSON)</label>
                <textarea name="fields" class="form-control" required></textarea>
            </div>
            <input type="hidden" name="company_id" value="1"> <!-- Set company_id as needed -->
            <button type="submit" class="btn btn-primary">Create</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/templates/create.blade.php ENDPATH**/ ?>