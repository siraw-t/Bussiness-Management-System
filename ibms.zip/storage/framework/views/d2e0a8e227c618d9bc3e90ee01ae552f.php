

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class="text-center text-warning mb-4">Edit Document</h1>
    <form action="<?php echo e(route('documents.update', $document)); ?>" method="POST" class="shadow p-4 rounded bg-light" style="max-width: 500px; margin: auto;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group mb-3">
            <label for="document_name">Document Name</label>
            <input type="text" class="form-control" id="document_name" name="document_name" value="<?php echo e(old('document_name', $document->document_name)); ?>" required>
        </div>
        <div class="form-group mb-3">
            <label for="document_type">Document Type</label>
            <select class="form-control" id="document_type" name="document_type" required>
                <option value="leave" <?php echo e($document->document_type == 'leave' ? 'selected' : ''); ?>>Leave</option>
                <option value="plan" <?php echo e($document->document_type == 'plan' ? 'selected' : ''); ?>>Plan</option>
                <option value="report" <?php echo e($document->document_type == 'report' ? 'selected' : ''); ?>>Report</option>
                <!-- Add any other specific document types here -->
            </select>
        </div>
        <div class="form-group mb-3">
            <label for="description">Description</label>
            <textarea class="form-control" id="description" name="description" rows="4"><?php echo e(old('description', $document->description)); ?></textarea>
        </div>
        <button type="submit" class="btn btn-warning btn-lg w-100">
            <i class="bi bi-pencil-square"></i> Update Document
        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/documents/edit.blade.php ENDPATH**/ ?>