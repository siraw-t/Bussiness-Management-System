



<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-5">
        <h2 class="text-center mb-4 text-info">Inventory Lists</h2>

        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover">
                <thead class="thead-dark">
                    <tr>
                        <th>Item Name</th>
                        <th>Tag Number</th>
                        <th>Item Type</th>
                        <th>Reference Number</th>
                        <th>Company Country</th>
                        <th>Quantity</th>
                        <th>Unit Price</th>
                        <th>Total Price</th>
                        <th>Description</th>
                        <th>Stock In Date</th>
                        <th>Stock Out Date</th>
                        <th>Issued Quantity</th>
                        <th>Issued Unit Price</th>
                        <th>Issued Total Price</th>
                        <th>Issued Department</th>
                        <th>Managed By</th>
                        <th>Received By</th>
                        <th>Balance Quantity</th>
                        <th>Balance Total Price</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $userCompanyId = auth()->user()->company_id;

                        // Filter inventories based on the logged-in user's company
                        $filteredInventories = $inventories->filter(function ($inventory) use ($userCompanyId) {
                            return ($inventory->manager && $inventory->manager->company_id == $userCompanyId) ||
                                ($inventory->approver && $inventory->approver->company_id == $userCompanyId);
                        });
                    ?>

                    <?php if($filteredInventories->isEmpty()): ?>
                        <tr>
                            <td colspan="21" class="text-center">No inventory items found.</td>
                        </tr>
                    <?php else: ?>
                        <?php $__currentLoopData = $filteredInventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="align-middle" style="transition: background-color 0.3s;">
                                <td><?php echo e($inventory->item_name); ?></td>
                                <td><?php echo e($inventory->tag_number ?? 'N/A'); ?></td>
                                <td><?php echo e(ucfirst($inventory->item_type)); ?></td>
                                <td><?php echo e($inventory->reference_number); ?></td>
                                <td><?php echo e($inventory->company_country); ?></td>
                                <td><?php echo e($inventory->quantity); ?> <?php echo e($inventory->unit); ?></td>
                                <td><?php echo e(number_format($inventory->unit_price, 2)); ?> <?php echo e($inventory->currency); ?></td>
                                <td><?php echo e(number_format($inventory->total_price, 2)); ?> <?php echo e($inventory->currency); ?></td>
                                <td><?php echo e($inventory->description ?? 'N/A'); ?></td>
                                <td><?php echo e($inventory->stock_in_date ? \Illuminate\Support\Carbon::parse($inventory->stock_in_date)->format('Y-m-d') : 'N/A'); ?>

                                </td>
                                <td><?php echo e($inventory->stock_out_date ? \Illuminate\Support\Carbon::parse($inventory->stock_out_date)->format('Y-m-d') : 'N/A'); ?>

                                </td>
                                <td><?php echo e($inventory->issued_quantity ?? 'N/A'); ?> <?php echo e($inventory->issued_unit); ?></td>
                                <td><?php echo e($inventory->issued_unit_price ? number_format($inventory->issued_unit_price, 2) : 'N/A'); ?>

                                    <?php echo e($inventory->issued_currency); ?>

                                </td>
                                <td><?php echo e($inventory->issued_total_price ? number_format($inventory->issued_total_price, 2) : 'N/A'); ?>

                                    <?php echo e($inventory->issued_currency); ?>

                                </td>
                                <td><?php echo e($inventory->issued_department ?? 'N/A'); ?></td>

                                <td><?php echo e($inventory->manager ? $inventory->manager->full_name : 'N/A'); ?></td>
                                <td><?php echo e($inventory->received_by ? optional($inventory->receivedBy)->full_name : 'N/A'); ?>

                                </td>
                                <td><?php echo e($inventory->balance_quantity ?? 'N/A'); ?> <?php echo e($inventory->unit); ?></td>
                                <td><?php echo e($inventory->balance_total_price ? number_format($inventory->balance_total_price, 2) : 'N/A'); ?>

                                    <?php echo e($inventory->currency); ?>

                                </td>
                                <td><?php echo e($inventory->created_at ? \Illuminate\Support\Carbon::parse($inventory->created_at)->format('Y-m-d H:i:s') : 'N/A'); ?>

                                </td>
                                <td><?php echo e($inventory->updated_at ? \Illuminate\Support\Carbon::parse($inventory->updated_at)->format('Y-m-d H:i:s') : 'N/A'); ?>

                                </td>

                                <td>
                                    <a href="<?php echo e(route('inventory.downloadPdf', $inventory->inventory_id)); ?>"
                                        class="btn btn-info">
                                        <i class="bi bi-download"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Optional: Add Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

    <!-- Custom CSS for hover effects -->
    <style>
        .table-hover tr:hover {
            background-color: #f8f9fa;
            /* Light grey on hover */
            cursor: pointer;
            /* Pointer cursor on hover */
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/display/index.blade.php ENDPATH**/ ?>