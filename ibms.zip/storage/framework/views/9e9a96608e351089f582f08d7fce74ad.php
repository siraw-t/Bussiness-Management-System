

<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-5">
        <h2 class="text-center text-primary mb-4"> Employee Plans</h2>

        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover">
                <thead class="thead-dark">
                    <tr>
                        <th>Full Name</th>
                        <th>Week</th>
                        <th>Plan</th>
                        <th>Submitted At</th>
                        <th>Urgent Issues</th>
                        <th>Status</th>
                        <th>Reference Number</th>
                        <th>Manager Comment</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($employeePlans->isEmpty()): ?>
                        <tr>
                            <td colspan="8" class="text-center">No plans found.</td>
                        </tr>
                    <?php else: ?>
                        <?php $__currentLoopData = $employeePlans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="align-middle" style="transition: background-color 0.3s;">
                                <td><?php echo e($plan->employee->full_name ?? 'N/A'); ?></td>
                                <td><?php echo e($plan->week); ?></td>
                                <td><?php echo e($plan->plan); ?></td>
                                <td><?php echo e($plan->submitted_at->format('Y-m-d H:i:s')); ?></td>
                                <td><?php echo e($plan->urgent_issues ?? 'N/A'); ?></td>
                                <td>
                                    <span
                                        class="badge <?php echo e($plan->status == 'approved' ? 'bg-success' : ($plan->status == 'rejected' ? 'bg-danger' : 'bg-warning')); ?>">
                                        <?php echo e(ucfirst($plan->status)); ?>

                                    </span>
                                </td>
                                <td><?php echo e($plan->reference_number); ?></td>
                                <td><?php echo e($plan->manager_comment ?? 'N/A'); ?></td>
                                <td>
                                    <a href="<?php echo e(route('weekly-plan.downloadPdf', $plan)); ?>" class="btn btn-info btn-sm">
                                        <i class="bi bi-download"></i> Download
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

    <style>
        .table-hover tr:hover {
            background-color: #f8f9fa;
            cursor: pointer;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/display/plan.blade.php ENDPATH**/ ?>