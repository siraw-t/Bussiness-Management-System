

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="text-center text-primary mb-4">Submit Weekly Plan</h1>

        <form action="<?php echo e(route('weekly-plan.store')); ?>" method="POST" class="shadow p-4 rounded bg-light"
            style="max-width: 600px; margin: auto;">
            <?php echo csrf_field(); ?>
            <div class="form-group mb-3">
                <label for="week">Week (YYYY-MM-DD)</label>
                <input type="date" name="week" class="form-control" required>
            </div>
            <div class="form-group mb-3">
                <label for="plan">Plan</label>
                <textarea name="plan" class="form-control" required></textarea>
            </div>
            <div class="form-group mb-3">
                <label for="urgent_issues">Urgent Issues</label>
                <textarea name="urgent_issues" class="form-control"></textarea>
            </div>
            <button type="submit" class="btn btn-success w-100">
                <i class="bi bi-check-lg"></i> Submit
            </button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/weekly-plan/create.blade.php ENDPATH**/ ?>