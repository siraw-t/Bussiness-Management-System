

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="text-center text-primary mb-4"> Purchase Requests</h1>

        

        <div class="text-center mb-4">
            <a href="<?php echo e(route('purchase-requests.create')); ?>" class="btn btn-primary btn-sm">
                <i class="bi bi-plus-lg"></i> Create New Purchase Request
            </a>
        </div>

        <div class="table-responsive">
            <table class="table table-striped table-hover table-bordered mt-3">
                <thead class="thead-dark">
                    <tr>
                        <th>Reference Number</th>
                        <th>Item Name</th>
                        <th>Description</th>
                        <th>Quantity</th>
                        <th>Unit</th>
                        <th>Price</th>
                        <th>Total Price</th>
                        <th>Company Country</th>
                        <th>Status</th>
                        <th>Finance Comment</th>
                        <th>Manager Comment</th>
                        <th>Checked By</th>
                        <th>Approved By</th>
                        <th>Attachments</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($request->reference_number); ?></td>
                            <td><?php echo e($request->item_name); ?></td>
                            <td><?php echo e($request->item_description); ?></td>
                            <td><?php echo e($request->quantity); ?> <?php echo e($request->unit); ?></td>
                            <td><?php echo e($request->unit); ?></td>
                            <td><?php echo e(number_format($request->price, 2)); ?> <?php echo e($request->currency); ?></td>
                            <td><?php echo e(number_format($request->total_price, 2)); ?> <?php echo e($request->currency); ?></td>
                            <td><?php echo e($request->company_country); ?></td>
                            <td>
                                <span
                                    class="badge <?php echo e($request->status === 'approved' ? 'bg-success' : ($request->status === 'pending' ? 'bg-warning' : 'bg-danger')); ?>">
                                    <?php echo e(ucfirst($request->status)); ?>

                                </span>
                            </td>
                            <td><?php echo e($request->finance_comment ?? 'N/A'); ?></td>
                            <td><?php echo e($request->manager_comment ?? 'N/A'); ?></td>
                            <td><?php echo e(optional(\App\Models\User::find($request->checked_by))->full_name ?? 'N/A'); ?></td>
                            <td><?php echo e(optional(\App\Models\User::find($request->approved_by))->full_name ?? 'N/A'); ?></td>
                            <td>
                                <?php if($request->attachments): ?>
                                    <ul>
                                        <?php $__currentLoopData = json_decode($request->attachments); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="<?php echo e(asset('storage/' . $attachment)); ?>"
                                                    target="_blank"><?php echo e(basename($attachment)); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <?php if($request->status === 'approved'): ?>
                                        <span class="btn btn-warning btn-sm me-2 disabled"
                                            title="Cannot edit approved requests">
                                            <i class="bi bi-pencil"></i>
                                        </span>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('purchase-requests.edit', $request)); ?>"
                                            class="btn btn-warning btn-sm me-2">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                    <?php endif; ?>

                                    <form action="<?php echo e(route('purchase-requests.destroy', $request)); ?>" method="POST"
                                        style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm me-2"
                                            onclick="return confirm('Are you sure?');"
                                            <?php if($request->status === 'approved'): ?> disabled <?php endif; ?>>
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>

                                    <a href="<?php echo e(route('purchase-requests.downloadPdf', $request)); ?>"
                                        class="btn btn-info btn-sm me-2">
                                        <i class="bi bi-file-earmark-pdf"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
    <style>
        .table-hover tr:hover {
            background-color: #f8f9fa;
            cursor: pointer;
        }

        @media (max-width: 375px) {
            .btn {
                font-size: 0.8rem;
                /* Smaller font size for mobile */
                padding: 0.4rem 0.6rem;
                /* Reduced padding */
            }

            .table th,
            .table td {
                font-size: 0.9rem;
                /* Smaller text for table */
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/purchase-requests/index.blade.php ENDPATH**/ ?>