

<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-5">
        <h2 class="text-center text-info mb-4">Budget Forecasting</h2>

        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover">
                <thead class="thead-dark">
                    <tr>
                        <th>Forecast Period</th>
                        <th>Budget Description</th>
                        <th>Budget Item</th>
                        <th>Budget Code</th>
                        <th>Department</th>
                        <th>Budget Source</th>
                        <th>Quantity</th>
                        <th>Unit Cost</th>
                        <th>Total Budget</th>
                        <th>Status</th>
                        <th>Manager Comment</th>
                        <th>Approved By</th>
                        <th>Reference Number</th>
                        <th>Company Country</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $userCompanyId = auth()->user()->company_id; // Get the user's company ID

                        // Filter budget forecasts for users belonging to the same company
                        $filteredBudgetForecasts = $budgetForecasts->filter(function ($forecast) use ($userCompanyId) {
                            return $forecast->creator->company_id == $userCompanyId; // Ensure the budget user is in the same company
                        });
                    ?>

                    <?php if($filteredBudgetForecasts->isEmpty()): ?>
                        <tr>
                            <td colspan="18" class="text-center">No budget forecasts found.</td>
                        </tr>
                    <?php else: ?>
                        <?php $__currentLoopData = $filteredBudgetForecasts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forecast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="align-middle" style="transition: background-color 0.3s;">
                                <td><?php echo e(ucfirst($forecast->forecast_period)); ?></td>
                                <td><?php echo e($forecast->budget_description); ?></td>
                                <td><?php echo e($forecast->budget_item); ?></td>
                                <td><?php echo e($forecast->budget_code); ?></td>
                                <td><?php echo e($forecast->department); ?></td>
                                <td><?php echo e($forecast->budget_source); ?></td>
                                <td><?php echo e($forecast->quantity); ?> <?php echo e($forecast->unit); ?></td>
                                <td><?php echo e(number_format($forecast->unit_cost, 2)); ?> <?php echo e($forecast->currency); ?></td>
                                <td><?php echo e(number_format($forecast->total_budget, 2)); ?> <?php echo e($forecast->currency); ?></td>
                                <td>
                                    <span
                                        class="badge <?php echo e($forecast->status === 'approved' ? 'bg-success' : ($forecast->status === 'pending' ? 'bg-warning' : 'bg-danger')); ?>">
                                        <?php echo e(ucfirst($forecast->status)); ?>

                                    </span>
                                </td>
                                <td><?php echo e($forecast->manager_comment ?? 'N/A'); ?></td>
                                <td><?php echo e(optional($forecast->approver)->full_name ?? 'N/A'); ?></td>
                                <td><?php echo e($forecast->reference_number); ?></td>
                                <td><?php echo e($forecast->company_country); ?></td>
                                <td><?php echo e($forecast->created_at->format('Y-m-d H:i:s')); ?></td>
                                <td><?php echo e($forecast->updated_at->format('Y-m-d H:i:s')); ?></td>
                                <td>
                                    <a href="<?php echo e(route('finance.budgets.downloadBudgetPdf', $forecast)); ?>"
                                        class="btn btn-info">
                                        PDF
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Optional: Add Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

    <!-- Custom CSS for hover effects -->
    <style>
        .table-hover tr:hover {
            background-color: #f8f9fa;
            /* Light grey on hover */
            cursor: pointer;
            /* Pointer cursor on hover */
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/display/budget.blade.php ENDPATH**/ ?>