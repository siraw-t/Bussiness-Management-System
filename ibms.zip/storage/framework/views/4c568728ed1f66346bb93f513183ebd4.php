

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="text-center text-primary mb-4"> Payment Requests</h1>

        

        <div class="text-center mb-4">
            <a href="<?php echo e(route('payment-requests.create')); ?>" class="btn btn-primary btn-sm">
                <i class="bi bi-plus-lg"></i> Create New Payment Request
            </a>
        </div>

        <div class="table-responsive">
            <table class="table table-striped table-hover table-bordered mt-3">
                <thead class="thead-dark">
                    <tr>
                        <th>Request Date</th>
                        <th>Reference No</th>
                        <th>Full Name</th>
                        <th>Department</th>
                        <th>Item Name</th>
                        <th>Quantity</th>
                        <th>Amount</th>
                        <th>VAT</th>
                        <th>Total</th>
                        <th>Withholding</th>
                        <th>Net Payment</th>
                        <th>Cost Center</th>
                        <th>Account Code</th>
                        <th>Company Country</th>
                        <th>Status</th>
                        <th>Finance Comment</th>
                        <th>Manager Comment</th>
                        <th>Reviewed By</th>
                        <th>Approved By</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="align-middle" style="transition: background-color 0.3s;">
                            <td><?php echo e($request->request_date ? $request->request_date->format('Y-m-d') : 'N/A'); ?></td>
                            <td><?php echo e($request->reference_no ?? 'N/A'); ?></td>
                            <td><?php echo e(optional($request->user)->full_name); ?></td>
                            <td><?php echo e($request->department ?? 'N/A'); ?></td>
                            <td><?php echo e($request->item_name); ?></td>
                            <td><?php echo e($request->quantity ?? 'N/A'); ?> <?php echo e($request->unit ?? 'N/A'); ?></td>
                            <td><?php echo e(number_format($request->amount, 2)); ?> <?php echo e($request->currency ?? 'N/A'); ?></td>
                            <td><?php echo e(number_format($request->vat, 2)); ?> <?php echo e($request->currency ?? 'N/A'); ?></td>
                            <td><?php echo e(number_format($request->total, 2)); ?> <?php echo e($request->currency ?? 'N/A'); ?></td>
                            <td><?php echo e(number_format($request->with_holding, 2)); ?> <?php echo e($request->currency ?? 'N/A'); ?></td>
                            <td><?php echo e(number_format($request->net_payment, 2)); ?> <?php echo e($request->currency ?? 'N/A'); ?></td>
                            <td><?php echo e($request->cost_center ?? 'N/A'); ?></td>
                            <td><?php echo e($request->account_code ?? 'N/A'); ?></td>
                            <td><?php echo e($request->company_country); ?></td>
                            <td>
                                <span
                                    class="badge <?php echo e($request->status === 'approved' ? 'bg-success' : ($request->status === 'pending' ? 'bg-warning' : 'bg-danger')); ?>">
                                    <?php echo e(ucfirst($request->status)); ?>

                                </span>
                            </td>
                            <td><?php echo e($request->finance_comment ?? 'N/A'); ?></td>
                            <td><?php echo e($request->manager_comment ?? 'N/A'); ?></td>
                            <td><?php echo e($request->reviewed_by ? optional(\App\Models\User::find($request->reviewed_by))->full_name : 'Not Checked'); ?>

                            </td>
                            <td><?php echo e($request->approved_by ? optional(\App\Models\User::find($request->approved_by))->full_name : 'Not Approved'); ?>

                            </td>
                            <td>
                                <?php if($request->status === 'approved'): ?>
                                    <span class="btn btn-warning btn-sm me-2 disabled"
                                        title="Cannot edit approved requests">
                                        <i class="bi bi-pencil"></i>
                                    </span>
                                <?php else: ?>
                                    <a href="<?php echo e(route('payment-requests.edit', $request)); ?>"
                                        class="btn btn-warning btn-sm me-2">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                <?php endif; ?>

                                <form action="<?php echo e(route('payment-requests.destroy', $request)); ?>" method="POST"
                                    style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm"
                                        onclick="return confirm('Are you sure you want to delete this request?');"
                                        <?php if($request->status === 'approved'): ?> disabled <?php endif; ?>>
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>

                                <a href="<?php echo e(route('payment-requests.downloadPdf', $request)); ?>"
                                    class="btn btn-info btn-sm">
                                    <i class="bi bi-file-earmark-pdf"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <style>
        @media (max-width: 375px) {
            .btn {
                font-size: 0.8rem;
                /* Smaller font size for mobile */
                padding: 0.4rem 0.6rem;
                /* Reduced padding */
            }

            .table th,
            .table td {
                font-size: 0.9rem;
                /* Smaller text for table */
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/payment-requests/index.blade.php ENDPATH**/ ?>