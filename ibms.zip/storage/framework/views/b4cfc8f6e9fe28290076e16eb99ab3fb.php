

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="text-center text-warning mb-4">Edit Budget Forecasting</h1>

        <form action="<?php echo e(route('finance.budgets.update', $budget->budget_id)); ?>" method="POST"
            class="shadow p-4 rounded bg-light" style="max-width: 500px; margin: auto;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group mb-3">
                <label for="forecast_period">Forecast Period</label>
                <select name="forecast_period" class="form-control" required>
                    <option value="" disabled>Select forecast period</option>
                    <option value="weekly" <?php echo e($budget->forecast_period == 'weekly' ? 'selected' : ''); ?>>Weekly</option>
                    <option value="monthly" <?php echo e($budget->forecast_period == 'monthly' ? 'selected' : ''); ?>>Monthly</option>
                    <option value="quarterly" <?php echo e($budget->forecast_period == 'quarterly' ? 'selected' : ''); ?>>Quarterly
                    </option>
                    <option value="annually" <?php echo e($budget->forecast_period == 'annually' ? 'selected' : ''); ?>>Annually
                    </option>
                </select>
            </div>
            <div class="form-group mb-3">
                <label for="budget_description">Budget Description</label>
                <textarea name="budget_description" class="form-control" placeholder="Add a description"><?php echo e($budget->budget_description); ?></textarea>
            </div>
            <div class="form-group mb-3">
                <label for="budget_item">Budget Item</label>
                <input type="text" name="budget_item" class="form-control" value="<?php echo e($budget->budget_item); ?>"
                    placeholder="Enter budget item">
            </div>
            <div class="form-group mb-3">
                <label for="budget_code">Budget Code</label>
                <input type="text" name="budget_code" class="form-control" value="<?php echo e($budget->budget_code); ?>"
                    placeholder="Enter budget code">
            </div>
            <div class="form-group mb-3">
                <label for="department">Department</label>
                <input type="text" name="department" class="form-control" value="<?php echo e($budget->department); ?>"
                    placeholder="Enter department">
            </div>
            <div class="form-group mb-3">
                <label for="budget_source">Budget Source</label>
                <input type="text" name="budget_source" class="form-control" value="<?php echo e($budget->budget_source); ?>"
                    placeholder="Enter budget source">
            </div>
            <div class="form-group mb-3">
                <label for="quantity">Quantity</label>
                <input type="number" name="quantity" class="form-control" value="<?php echo e($budget->quantity); ?>"
                    placeholder="Enter quantity">
            </div>
            <div class="form-group mb-3">
                <label for="unit">Unit</label>
                <select name="unit" class="form-control" required>
                    <option value="" disabled>Select unit</option>
                    <option value="pcs" <?php echo e($budget->unit == 'pcs' ? 'selected' : ''); ?>>Pieces</option>
                    <option value="kg" <?php echo e($budget->unit == 'kg' ? 'selected' : ''); ?>>Kilograms</option>
                    <option value="liters" <?php echo e($budget->unit == 'liters' ? 'selected' : ''); ?>>Liters</option>
                    <option value="boxes" <?php echo e($budget->unit == 'boxes' ? 'selected' : ''); ?>>Boxes</option>
                </select>
            </div>
            <div class="form-group mb-3">
                <label for="unit_cost">Unit Cost</label>
                <input type="number" name="unit_cost" class="form-control" value="<?php echo e($budget->unit_cost); ?>" step="0.01"
                    placeholder="Enter unit cost">
            </div>
            <div class="form-group mb-3">
                <label for="currency">Currency</label>
                <select name="currency" class="form-control" required>
                    <option value="" disabled>Select currency</option>
                    <option value="USD" <?php echo e($budget->currency == 'USD' ? 'selected' : ''); ?>>USD</option>
                    <option value="EUR" <?php echo e($budget->currency == 'EUR' ? 'selected' : ''); ?>>EUR</option>
                    <option value="ETB" <?php echo e($budget->currency == 'ETB' ? 'selected' : ''); ?>>ETB</option>
                    <option value="UGX" <?php echo e($budget->currency == 'UGX' ? 'selected' : ''); ?>>UGX</option>
                </select>
            </div>

            <button type="submit" class="btn btn-warning btn-lg w-100">Update Budget</button>
            <a href="<?php echo e(route('finance.budgets.index')); ?>" class="btn btn-secondary btn-lg w-100 mt-3">Cancel</a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/finance/budgets/edit.blade.php ENDPATH**/ ?>