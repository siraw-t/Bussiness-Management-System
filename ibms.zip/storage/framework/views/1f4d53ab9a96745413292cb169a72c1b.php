

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="text-center text-primary mb-4"> Weekly Plans</h1>

        

        <div class="text-center mb-4">
            <a href="<?php echo e(route('weekly-plan.create')); ?>" class="btn btn-primary btn-sm">
                <i class="bi bi-plus-lg"></i> Submit New Weekly Plan
            </a>
        </div>

        <div class="table-responsive">
            <table class="table table-striped table-hover mt-3">
                <thead class="thead-dark">
                    <tr>
                        <th>Full Name</th>
                        <th>Company Country</th>
                        <th>Week</th>
                        <th>Plan</th>
                        <th>Submitted At</th>
                        <th>Manager Comment</th>
                        <th>Urgent Issues</th>
                        <th>Reference Number</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($plan->employee->full_name ?? 'N/A'); ?></td>
                            <td><?php echo e($plan->employee->company->country ?? 'N/A'); ?></td>
                            <td><?php echo e($plan->week); ?></td>
                            <td><?php echo e($plan->plan); ?></td>
                            <td><?php echo e($plan->submitted_at); ?></td>
                            <td><?php echo e($plan->manager_comment ?? 'N/A'); ?></td>
                            <td><?php echo e($plan->urgent_issues ?? 'N/A'); ?></td>
                            <td><?php echo e($plan->reference_number); ?></td>
                            <td>
                                <span
                                    class="badge <?php echo e($plan->status === 'approved' ? 'bg-success' : ($plan->status === 'pending' ? 'bg-warning' : 'bg-danger')); ?>">
                                    <?php echo e(ucfirst($plan->status)); ?>

                                </span>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <?php if($plan->status === 'approved'): ?>
                                        <span class="btn btn-warning btn-sm me-2 disabled"
                                            title="Cannot edit approved plans">
                                            <i class="bi bi-pencil"></i>
                                        </span>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('weekly-plan.edit', $plan)); ?>"
                                            class="btn btn-warning btn-sm me-2">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                    <?php endif; ?>

                                    <form action="<?php echo e(route('weekly-plan.destroy', $plan)); ?>" method="POST"
                                        style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm me-2"
                                            onclick="return confirm('Are you sure?');"
                                            <?php if($plan->status === 'approved'): ?> disabled <?php endif; ?>>
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>

                                    <a href="<?php echo e(route('weekly-plan.downloadPdf', $plan)); ?>" class="btn btn-info btn-sm">
                                        <i class="bi bi-file-earmark-pdf"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
    <style>
        .table-hover tr:hover {
            background-color: #f0f8ff;
            transition: background-color 0.3s;
            cursor: pointer;
        }

        @media (max-width: 375px) {
            .btn {
                font-size: 0.8rem;
                /* Smaller font size for mobile */
                padding: 0.4rem 0.6rem;
                /* Reduced padding */
            }

            .table th,
            .table td {
                font-size: 0.9rem;
                /* Smaller text for table */
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/weekly-plan/index.blade.php ENDPATH**/ ?>