

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="text-center text-info mb-4">Budget Forecasting</h1>
        <div class="text-center mb-3">
            <a href="<?php echo e(route('finance.budgets.create')); ?>" class="btn btn-primary btn-sm">
                <i class="bi bi-plus-circle"></i> Add Budget
            </a>
        </div>

        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover">
                <thead class="thead-dark">
                    <tr>
                        <th>Reference Number</th>
                        <th>Forecast Period</th>
                        <th>Budget Description</th>
                        <th>Budget Item</th>
                        <th>Budget Code</th>
                        <th>Department</th>
                        <th>Budget Source</th>
                        <th>Quantity</th>
                        <th>Unit</th>
                        <th>Unit Cost</th>
                        <th>Currency</th>
                        <th>Total Budget</th>
                        <th>Status</th>
                        <th>Manager Comments</th>
                        <th>Approved By</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $budgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $budget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($budget->reference_number); ?></td>
                            <td><?php echo e($budget->forecast_period); ?></td>
                            <td><?php echo e($budget->budget_description); ?></td>
                            <td><?php echo e($budget->budget_item); ?></td>
                            <td><?php echo e($budget->budget_code); ?></td>
                            <td><?php echo e($budget->department); ?></td>
                            <td><?php echo e($budget->budget_source); ?></td>
                            <td><?php echo e($budget->quantity); ?></td>
                            <td><?php echo e($budget->unit); ?></td>
                            <td><?php echo e(number_format($budget->unit_cost, 2)); ?></td>
                            <td><?php echo e($budget->currency); ?></td>
                            <td><?php echo e(number_format($budget->total_budget, 2)); ?> <?php echo e($budget->currency); ?></td>
                            <td>
                                <span class="badge <?php echo e($budget->status === 'approved' ? 'bg-success' : 'bg-warning'); ?>">
                                    <?php echo e(ucfirst($budget->status)); ?>

                                </span>
                            </td>
                            <td><?php echo e($budget->manager_comment ?? 'N/A'); ?></td>
                            <td><?php echo e($budget->approver ? $budget->approver->full_name : 'N/A'); ?></td>
                            <td>
                                <div class="btn-group" role="group">
                                    <?php if($budget->status !== 'approved'): ?>
                                        <a href="<?php echo e(route('finance.budgets.edit', $budget)); ?>"
                                            class="btn btn-warning btn-sm me-2" title="Edit Budget">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <form action="<?php echo e(route('finance.budgets.destroy', $budget)); ?>" method="POST"
                                            style="display:inline;"
                                            onsubmit="return confirm('Are you sure you want to delete this budget item?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm me-2" title="Delete Budget">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="btn btn-warning btn-sm me-2 disabled"
                                            title="Cannot edit approved budgets">
                                            <i class="bi bi-pencil"></i>
                                        </span>
                                        <span class="btn btn-danger btn-sm me-2 disabled"
                                            title="Cannot delete approved budgets">
                                            <i class="bi bi-trash"></i>
                                        </span>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('finance.budgets.downloadBudgetPdf', $budget)); ?>"
                                        class="btn btn-info btn-sm" title="Download PDF">
                                        <i class="bi bi-file-earmark-pdf"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if($budgets->isEmpty()): ?>
                        <tr>
                            <td colspan="15" class="text-center">No budget items found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <style>
        .table-hover tr:hover {
            background-color: #f8f9fa;
            /* Light grey on hover */
            cursor: pointer;
            /* Pointer cursor on hover */
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/finance/budgets/index.blade.php ENDPATH**/ ?>