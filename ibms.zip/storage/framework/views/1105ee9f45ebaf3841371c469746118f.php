

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="text-center text-primary mb-4">Edit Purchase Request</h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <form action="<?php echo e(route('purchase-requests.update', $purchaseRequest)); ?>" method="POST" enctype="multipart/form-data"
            class="shadow p-4 rounded bg-light" style="max-width: 600px; margin: auto;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group mb-3">
                <label for="item_name">Item Name</label>
                <input type="text" name="item_name" class="form-control"
                    value="<?php echo e(old('item_name', $purchaseRequest->item_name)); ?>" required>
            </div>

            <div class="form-group mb-3">
                <label for="item_description">Item Description</label>
                <textarea name="item_description" class="form-control" rows="3"><?php echo e(old('item_description', $purchaseRequest->item_description)); ?></textarea>
            </div>

            <div class="form-group mb-3">
                <label for="quantity">Quantity</label>
                <input type="number" name="quantity" class="form-control"
                    value="<?php echo e(old('quantity', $purchaseRequest->quantity)); ?>" required>
            </div>

            <div class="form-group mb-3">
                <label for="unit">Unit</label>
                <select name="unit" class="form-control" required>
                    <option value="kg" <?php echo e($purchaseRequest->unit == 'kg' ? 'selected' : ''); ?>>KG</option>
                    <option value="ltr" <?php echo e($purchaseRequest->unit == 'ltr' ? 'selected' : ''); ?>>LTR</option>
                    <option value="pcs" <?php echo e($purchaseRequest->unit == 'pcs' ? 'selected' : ''); ?>>Pcs</option>
                </select>
            </div>

            <div class="form-group mb-3">
                <label for="price">Price</label>
                <input type="number" step="0.01" name="price" class="form-control"
                    value="<?php echo e(old('price', $purchaseRequest->price)); ?>" required>
            </div>

            <div class="form-group mb-3">
                <label for="currency">Currency</label>
                <select name="currency" class="form-control" required>
                    <option value="USD" <?php echo e($purchaseRequest->currency == 'USD' ? 'selected' : ''); ?>>USD</option>
                    <option value="ETB" <?php echo e($purchaseRequest->currency == 'ETB' ? 'selected' : ''); ?>>ETB</option>
                    <option value="UGX" <?php echo e($purchaseRequest->currency == 'UGX' ? 'selected' : ''); ?>>UGX</option>
                </select>
            </div>

            <div class="form-group mb-3">
                <label for="attachments">Attachments</label>
                <input type="file" name="attachments[]" class="form-control" multiple>
                <?php if($purchaseRequest->attachments): ?>
                    <p>Current Attachments:</p>
                    <ul>
                        <?php $__currentLoopData = json_decode($purchaseRequest->attachments); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(asset($attachment)); ?>" target="_blank"><?php echo e(basename($attachment)); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>

            <button type="submit" class="btn btn-success w-100">
                <i class="bi bi-check-lg"></i> Update
            </button>
            <a href="<?php echo e(route('purchase-requests.index')); ?>" class="btn btn-secondary w-100 mt-2">Cancel</a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/purchase-requests/edit.blade.php ENDPATH**/ ?>