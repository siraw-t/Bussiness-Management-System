

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Edit Request Form Template</h1>
        <form action="<?php echo e(route('templates.update', $template->form_id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label for="form_name" class="form-label">Form Name</label>
                <input type="text" name="form_name" class="form-control" value="<?php echo e($template->form_name); ?>" required>
            </div>
            <div class="mb-3">
                <label for="fields" class="form-label">Fields (JSON)</label>
                <textarea name="fields" class="form-control" required><?php echo e($template->fields); ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/templates/edit.blade.php ENDPATH**/ ?>