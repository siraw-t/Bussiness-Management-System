

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="text-center text-warning mb-4">Edit Payroll</h1>

        <form action="<?php echo e(route('finance.payrolls.update', $payroll->payroll_id)); ?>" method="POST"
            class="shadow p-4 rounded bg-light" style="max-width: 500px; margin: auto;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group mb-3">
                <label for="employee_id">Employee</label>
                <select name="employee_id" class="form-control" required>
                    <option value="">-- Select Employee --</option>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($employee->user_id); ?>"
                            <?php echo e($employee->user_id == $payroll->employee_id ? 'selected' : ''); ?>>
                            <?php echo e($employee->username); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group mb-3">
                <label for="pay_period">Pay Period</label>
                <input type="text" name="pay_period" class="form-control" value="<?php echo e($payroll->pay_period); ?>" required
                    placeholder="Enter pay period">
            </div>

            <div class="form-group mb-3">
                <label for="job_title">Job Title</label>
                <input type="text" name="job_title" class="form-control" value="<?php echo e($payroll->job_title); ?>" required
                    placeholder="Enter job title">
            </div>

            <div class="form-group mb-3">
                <label for="no_of_days">Number of Days</label>
                <input type="number" name="no_of_days" class="form-control" value="<?php echo e($payroll->no_of_days); ?>" required
                    placeholder="Enter number of days">
            </div>

            <div class="form-group mb-3">
                <label for="basic_salary">Basic Salary</label>
                <input type="number" name="basic_salary" class="form-control" value="<?php echo e($payroll->basic_salary); ?>" required
                    step="0.01" placeholder="Enter basic salary">
            </div>

            <div class="form-group mb-3">
                <label for="currency">Currency</label>
                <select name="currency" class="form-control" required>
                    <option value="">-- Select Currency --</option>
                    <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($currency); ?>" <?php echo e($payroll->currency == $currency ? 'selected' : ''); ?>>
                            <?php echo e($currency); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group mb-3">
                <label for="transport_allowance">Transport Allowance</label>
                <input type="number" name="transport_allowance" class="form-control"
                    value="<?php echo e($payroll->transport_allowance); ?>" step="0.01" placeholder="Enter transport allowance">
            </div>

            <div class="form-group mb-3">
                <label for="taxable_transport_allowance">Taxable Transport Allowance</label>
                <input type="number" name="taxable_transport_allowance" class="form-control"
                    value="<?php echo e($payroll->taxable_transport_allowance); ?>" step="0.01"
                    placeholder="Enter taxable transport allowance">
            </div>

            <div class="form-group mb-3">
                <label for="position_allowance">Position Allowance</label>
                <input type="number" name="position_allowance" class="form-control"
                    value="<?php echo e($payroll->position_allowance); ?>" step="0.01" placeholder="Enter position allowance">
            </div>

            <div class="form-group mb-3">
                <label for="salary_advance">Salary Advance</label>
                <input type="number" name="salary_advance" class="form-control" value="<?php echo e($payroll->salary_advance); ?>"
                    step="0.01" placeholder="Enter salary advance">
            </div>

            <div class="form-group mb-3">
                <label for="pension_fund_7">Pension Fund 7%</label>
                <input type="number" name="pension_fund_7" class="form-control" value="<?php echo e($payroll->pension_fund_7); ?>"
                    step="0.01" placeholder="Enter pension fund 7%">
            </div>

            <div class="form-group mb-3">
                <label for="pension_fund_11">Pension Fund 11%</label>
                <input type="number" name="pension_fund_11" class="form-control" value="<?php echo e($payroll->pension_fund_11); ?>"
                    step="0.01" placeholder="Enter pension fund 11%">
            </div>

            <div class="form-group mb-4">
                <label for="status">Status</label>
                <select name="status" class="form-control">
                    <option value="pending" <?php echo e($payroll->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                    <option value="approved" <?php echo e($payroll->status == 'approved' ? 'selected' : ''); ?>>Approved</option>
                    <option value="rejected" <?php echo e($payroll->status == 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                </select>
            </div>

            <button type="submit" class="btn btn-warning btn-lg w-100">
                <i class="bi bi-pencil-square"></i> Update Payroll
            </button>
            <a href="<?php echo e(route('finance.payrolls.index')); ?>" class="btn btn-secondary btn-lg w-100 mt-3">Cancel</a>
        </form>
    </div>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
    <style>
        .form-control:focus {
            box-shadow: none;
            border-color: #80bdff;
        }

        .btn-warning {
            transition: background-color 0.3s ease;
        }

        .btn-warning:hover {
            background-color: #ffca2c;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/finance/payrolls/edit.blade.php ENDPATH**/ ?>