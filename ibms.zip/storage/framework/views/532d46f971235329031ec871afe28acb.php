

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="text-center text-primary mb-4">Edit Weekly Report</h1>

        <?php
            $lastWeekPlan = \App\Models\EmployeePlan::where('employee_id', Auth::id())
                ->where('week', '<', now()->startOfWeek())
                ->orderBy('week', 'desc')
                ->first();
        ?>

        <div class="mb-4">
            <h5>Last Week's Plan</h5>
            <?php if($lastWeekPlan): ?>
                <p><strong>Plan:</strong> <?php echo e($lastWeekPlan->plan); ?></p>
                <p><strong>Urgent Issues:</strong> <?php echo e($lastWeekPlan->urgent_issues ?? 'None'); ?></p>
                <p><strong>Status:</strong> <?php echo e(ucfirst($lastWeekPlan->status)); ?></p>
            <?php else: ?>
                <p>No plan available for last week.</p>
            <?php endif; ?>
        </div>

        <form action="<?php echo e(route('weekly-reports.update', $weeklyReport)); ?>" method="POST" class="shadow p-4 rounded bg-light"
            style="max-width: 500px; margin: auto;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group mb-3">
                <label for="week">Week</label>
                <input type="date" name="week" class="form-control" value="<?php echo e(old('week', $weeklyReport->week)); ?>"
                    required>
            </div>
            <div class="form-group mb-3">
                <label for="report">Report</label>
                <textarea name="report" class="form-control" rows="4" required placeholder="Update your report..."><?php echo e(old('report', $weeklyReport->report)); ?></textarea>
            </div>
            <div class="form-group mb-3">
                <label for="tasks_in_progress">Tasks In Progress</label>
                <textarea name="tasks_in_progress" class="form-control" rows="3" placeholder="Current tasks..."><?php echo e(old('tasks_in_progress', $weeklyReport->tasks_in_progress)); ?></textarea>
            </div>
            <div class="form-group mb-3">
                <label for="tasks_completed">Tasks Completed</label>
                <textarea name="tasks_completed" class="form-control" rows="3" placeholder="Completed tasks..."><?php echo e(old('tasks_completed', $weeklyReport->tasks_completed)); ?></textarea>
            </div>
            <div class="form-group mb-3">
                <label for="self_assessment">Self Assessment</label>
                <textarea name="self_assessment" class="form-control" rows="3" placeholder="Your self-assessment..."><?php echo e(old('self_assessment', $weeklyReport->self_assessment)); ?></textarea>
            </div>
            <button type="submit" class="btn btn-warning btn-lg w-100">
                <i class="bi bi-pencil-square"></i> Update
            </button>
            <a href="<?php echo e(route('weekly-reports.index')); ?>" class="btn btn-secondary btn-lg w-100 mt-2">Cancel</a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/weekly-reports/edit.blade.php ENDPATH**/ ?>