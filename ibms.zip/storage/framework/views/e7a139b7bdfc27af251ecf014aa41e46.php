

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="text-center text-primary mb-4"> Weekly Reports</h1>

        

        <div class="text-center mb-4">
            <a href="<?php echo e(route('weekly-reports.create')); ?>" class="btn btn-primary btn-sm">
                <i class="bi bi-plus-circle"></i> Submit New Weekly Report
            </a>
        </div>

        <div class="table-responsive">
            <table class="table table-hover mt-3">
                <thead class="thead-dark">
                    <tr>
                        <th>Full Name</th>
                        <th>Company Country</th>
                        <th>Week</th>
                        <th>Last Week's Plan</th>
                        <th>Report</th>
                        <th>Tasks In Progress</th>
                        <th>Tasks Completed</th>
                        <th>Self Assessment</th>
                        <th>Submitted At</th>
                        <th>Reference Number</th>
                        <th>Status</th>
                        <th>Manager Comment</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            // Fetch the plan for the same week as the report
                            $lastWeekPlan = \App\Models\EmployeePlan::where('employee_id', $report->employee_id)
                                ->where('week', $report->week)
                                ->orderBy('week', 'desc')
                                ->first();
                        ?>
                        <tr>
                            <td><?php echo e($report->employee->full_name); ?></td>
                            <td><?php echo e($report->employee->company->country ?? 'N/A'); ?></td>
                            <td><?php echo e($report->week); ?></td>
                            <td>
                                <?php if($lastWeekPlan): ?>
                                    <?php echo e($lastWeekPlan->plan); ?>

                                <?php else: ?>
                                    <span class="text-muted">No plan available</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($report->report); ?></td>
                            <td><?php echo e($report->tasks_in_progress ?? 'N/A'); ?></td>
                            <td><?php echo e($report->tasks_completed ?? 'N/A'); ?></td>
                            <td><?php echo e($report->self_assessment ?? 'N/A'); ?></td>
                            <td><?php echo e($report->submitted_at->format('Y-m-d H:i')); ?></td>
                            <td><?php echo e($report->reference_number); ?></td>
                            <td>
                                <span
                                    class="badge <?php echo e($report->status === 'approved' ? 'bg-success' : ($report->status === 'pending' ? 'bg-warning' : 'bg-danger')); ?>">
                                    <?php echo e(ucfirst($report->status)); ?>

                                </span>
                            </td>
                            <td><?php echo e($report->manager_comment ?? 'N/A'); ?></td>
                            <td class="d-flex justify-content-around">
                                <?php if($report->status === 'approved'): ?>
                                    <span class="btn btn-warning btn-sm me-1 disabled" title="Cannot edit approved reports">
                                        <i class="bi bi-pencil"></i>
                                    </span>
                                <?php else: ?>
                                    <a href="<?php echo e(route('weekly-reports.edit', $report)); ?>"
                                        class="btn btn-warning btn-sm me-1">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                <?php endif; ?>

                                <form action="<?php echo e(route('weekly-reports.destroy', $report)); ?>" method="POST"
                                    class="me-1">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm"
                                        onclick="return confirm('Are you sure?');"
                                        <?php if($report->status === 'approved'): ?> disabled <?php endif; ?>>
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>

                                <a href="<?php echo e(route('weekly-reports.downloadPdf', $report->report_id)); ?>"
                                    class="btn btn-info btn-sm">
                                    <i class="bi bi-file-earmark-pdf"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
    <style>
        .table-hover tr:hover {
            background-color: #f8f9fa;
            cursor: pointer;
        }

        @media (max-width: 768px) {
            .table-responsive {
                overflow-x: auto;
            }

            .btn {
                font-size: 0.8rem;
                /* Smaller font size for mobile */
                padding: 0.4rem 0.6rem;
                /* Reduced padding */
            }

            .table th,
            .table td {
                font-size: 0.9rem;
                /* Smaller text for table */
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/weekly-reports/index.blade.php ENDPATH**/ ?>