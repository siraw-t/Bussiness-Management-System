

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="text-center text-primary mb-4">Leave Requests</h1>

        

        <div class="text-center mb-4">
            <a href="<?php echo e(route('leave-requests.create')); ?>" class="btn btn-primary btn-sm">
                <i class="bi bi-plus-lg"></i> Create New Leave Request
            </a>
        </div>

        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th>Full Name</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Leave Type</th>
                        <th>Other Reason</th>
                        <th>Employee Signature</th>
                        <th>Uploaded File</th>
                        <th>Status</th>
                        <th>Approved By</th>
                        <th>Manager Comments</th>
                        <th>Company Country</th>
                        <th>Reference Number</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(Auth::user()->full_name); ?></td>
                            <td><?php echo e($request->start_date); ?></td>
                            <td><?php echo e($request->end_date); ?></td>
                            <td><?php echo e(ucfirst(str_replace('_', ' ', $request->leave_type))); ?></td>
                            <td><?php echo e($request->other_reason ?? 'N/A'); ?></td>
                            <td>
                                <?php if($request->employee_signature): ?>
                                    <img src="<?php echo e(asset('storage/' . $request->employee_signature)); ?>" alt="Signature"
                                        style="width: 60px;">
                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($request->attachment): ?>
                                    <a href="<?php echo e(asset('storage/' . $request->attachment)); ?>" target="_blank"
                                        class="btn btn-link btn-sm">View File</a>
                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            </td>
                            <td>
                                <span
                                    class="badge <?php echo e($request->status === 'approved' ? 'bg-success' : ($request->status === 'pending' ? 'bg-warning' : 'bg-danger')); ?>">
                                    <?php echo e(ucfirst($request->status)); ?>

                                </span>
                            </td>
                            <td><?php echo e(optional(\App\Models\User::find($request->approved_by))->full_name ?? 'N/A'); ?></td>
                            <td><?php echo e($request->manager_comments ?? 'N/A'); ?></td>
                            <td><?php echo e($request->company_country); ?></td>
                            <td><?php echo e($request->reference_number); ?></td>
                            <td><?php echo e($request->created_at->format('Y-m-d H:i:s')); ?></td>
                            <td><?php echo e($request->updated_at->format('Y-m-d H:i:s')); ?></td>
                            <td>
                                <div class="btn-group" role="group">
                                    <?php if($request->status === 'approved'): ?>
                                        <span class="btn btn-warning btn-sm me-2 disabled"
                                            title="Cannot edit approved requests">
                                            <i class="bi bi-pencil"></i>
                                        </span>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('leave-requests.edit', $request)); ?>"
                                            class="btn btn-warning btn-sm me-2">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                    <?php endif; ?>

                                    <form action="<?php echo e(route('leave-requests.destroy', $request)); ?>" method="POST"
                                        style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm me-2"
                                            onclick="return confirm('Are you sure?');"
                                            <?php if($request->status === 'approved'): ?> disabled <?php endif; ?>>
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>

                                    <a href="<?php echo e(route('leave-requests.downloadPdf', $request)); ?>"
                                        class="btn btn-info btn-sm me-2">
                                        <i class="bi bi-file-earmark-pdf"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <style>
        @media (max-width: 375px) {
            .btn-group-vertical {
                flex-direction: column;
            }

            .btn {
                font-size: 0.8rem;
                /* Smaller font size for mobile */
                padding: 0.5rem;
                /* Reduced padding */
            }

            img {
                width: 50px;
                /* Smaller image for signatures */
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/leave-requests/index.blade.php ENDPATH**/ ?>