

<?php
    function renderFields($fields)
    {
        $fieldsArray = json_decode($fields, true);
        $html = '';

        foreach ($fieldsArray as $field) {
            if (!isset($field['name'], $field['label'], $field['type'])) {
                continue; // Skip if essential keys are missing
            }

            $required = isset($field['required']) && $field['required'] ? 'required' : '';
            $label = "<label for=\"{$field['name']}\">{$field['label']}</label>";

            switch ($field['type']) {
                case 'text':
                case 'email':
                case 'date':
                case 'number':
                    $html .= "<div class=\"mb-3\">
                            $label
                            <input type=\"{$field['type']}\" name=\"{$field['name']}\" class=\"form-control\" id=\"{$field['name']}\" $required>
                          </div>";
                    break;

                case 'textarea':
                    $html .= "<div class=\"mb-3\">
                            $label
                            <textarea name=\"{$field['name']}\" class=\"form-control\" id=\"{$field['name']}\" $required></textarea>
                          </div>";
                    break;

                case 'select':
                    if (!isset($field['options'])) {
                        break; // Skip if options are not defined
                    }
                    $options = '';
                    foreach ($field['options'] as $option) {
                        $options .= "<option value=\"$option\">$option</option>";
                    }
                    $html .= "<div class=\"mb-3\">
                            $label
                            <select name=\"{$field['name']}\" class=\"form-control\" id=\"{$field['name']}\" $required>
                                $options
                            </select>
                          </div>";
                    break;

                case 'file':
                    $html .= "<div class=\"mb-3\">
                            $label
                            <input type=\"file\" name=\"{$field['name']}\" class=\"form-control\" id=\"{$field['name']}\" $required>
                          </div>";
                    break;

                default:
                    break; // Skip unsupported field types
            }
        }

        return $html;
    }
?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row mb-4">
            <div class="col-md-12 text-center">
                <div class="card text-bg-primary mb-4"
                    style="max-width: 600px; margin: auto; border-radius: 15px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);">
                    <div class="card-body">
                        <h1 class="text-white" style="font-size: 1.5rem;">
                            <i class="bi bi-file-earmark-text" style="font-size: 1.3rem;"></i> Welcome to
                            <?php echo e(Auth::user()->company->company_name); ?>

                        </h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="text-center mt-4">
            <h2 class="text-secondary mb-3" style="font-size: 2rem;">Manage Request Form Templates</h2>
            <a href="<?php echo e(route('templates.create')); ?>" class="btn btn-primary mb-3"
                style="border-radius: 20px; padding: 10px 20px; font-size: 1.2rem;">
                <i class="bi bi-plus-circle"></i> Create Template
            </a>
        </div>

        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead class="table-light">
                    <tr>
                        <th>Form Name</th>
                        <th>Fields</th>
                        <th>Created By</th>
                        <th>Company ID</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($template->form_name); ?></td>
                            <td>
                                <button type="button" class="btn btn-info btn-sm" data-toggle="modal"
                                    data-target="#fieldsModal<?php echo e($template->form_id); ?>">
                                    View Fields
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="fieldsModal<?php echo e($template->form_id); ?>" tabindex="-1"
                                    role="dialog" aria-labelledby="fieldsModalLabel<?php echo e($template->form_id); ?>"
                                    aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="fieldsModalLabel<?php echo e($template->form_id); ?>">Fields
                                                    for <?php echo e($template->form_name); ?></h5>
                                                <button type="button" class="close" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <form>
                                                    <?php echo renderFields($template->fields); ?>

                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td><?php echo e($template->created_by); ?></td>
                            <td><?php echo e($template->company_id); ?></td>
                            <td>
                                <a href="<?php echo e(route('templates.edit', $template->form_id)); ?>" class="btn btn-warning btn-sm"
                                    style="border-radius: 20px;">
                                    <i class="bi bi-pencil"></i> Edit
                                </a>
                                <form action="<?php echo e(route('templates.destroy', $template->form_id)); ?>" method="POST"
                                    class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm" style="border-radius: 20px;"
                                        onclick="return confirm('Are you sure you want to delete this template?');">
                                        <i class="bi bi-trash"></i> Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/templates/index.blade.php ENDPATH**/ ?>