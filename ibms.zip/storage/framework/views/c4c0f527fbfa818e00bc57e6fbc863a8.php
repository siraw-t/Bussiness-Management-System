

<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-5">
        <h2 class="text-center text-info mb-4">Payment Requests</h2>

        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover">
                <thead class="thead-dark">
                    <tr>
                        <th>Reference No</th>
                        <th>Request Date</th>
                        <th>Department</th>
                        <th>Finance Comment</th>
                        <th>Item Description</th>
                        <th>Item Name</th>
                        <th>Quantity</th>
                        <th>Amount</th>
                        <th>VAT</th>
                        <th>Total</th>
                        <th>Net Payment</th>
                        <th>Withholding</th>
                        <th>Cost Center</th>
                        <th>Account Code</th>
                        <th>Status</th>
                        <th>Manager Comment</th>
                        <th>Checked By</th>
                        <th>Approved By</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $companyId = auth()->user()->company_id;

                        // Filter payment requests to show only those from the user's company
                        $filteredPaymentRequests = $paymentRequests->filter(function ($request) use ($companyId) {
                            return $request->user->company_id == $companyId;
                        });
                    ?>

                    <?php if($filteredPaymentRequests->isEmpty()): ?>
                        <tr>
                            <td colspan="21" class="text-center">No payment requests found.</td>
                        </tr>
                    <?php else: ?>
                        <?php $__currentLoopData = $filteredPaymentRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="align-middle" style="transition: background-color 0.3s;">
                                <td><?php echo e($request->reference_no ?? 'N/A'); ?></td>
                                <td><?php echo e($request->request_date ? $request->request_date->format('Y-m-d') : 'N/A'); ?></td>
                                <td><?php echo e($request->department ?? 'N/A'); ?></td>
                                <td><?php echo e($request->finance_comment ?? 'N/A'); ?></td>
                                <td><?php echo e($request->item_description); ?></td>
                                <td><?php echo e($request->item_name ?? 'N/A'); ?></td>
                                <td><?php echo e($request->quantity ?? 'N/A'); ?> <?php echo e($request->unit ?? 'N/A'); ?></td>
                                <td><?php echo e(number_format($request->amount, 2)); ?> <?php echo e($request->currency ?? 'N/A'); ?></td>
                                <td><?php echo e(number_format($request->vat, 2) ?? '0.00'); ?> <?php echo e($request->currency ?? 'N/A'); ?></td>
                                <td><?php echo e(number_format($request->total, 2)); ?> <?php echo e($request->currency ?? 'N/A'); ?></td>
                                <td><?php echo e(number_format($request->net_payment, 2)); ?> <?php echo e($request->currency ?? 'N/A'); ?></td>
                                <td><?php echo e(number_format($request->with_holding, 2) ?? '0.00'); ?>

                                    <?php echo e($request->currency ?? 'N/A'); ?></td>
                                <td><?php echo e($request->cost_center ?? 'N/A'); ?></td>
                                <td><?php echo e($request->account_code ?? 'N/A'); ?></td>
                                <td>
                                    <span
                                        class="badge <?php echo e($request->status === 'approved' ? 'bg-success' : ($request->status === 'pending' ? 'bg-warning' : 'bg-danger')); ?>">
                                        <?php echo e(ucfirst($request->status)); ?>

                                    </span>
                                </td>
                                <td><?php echo e($request->manager_comment ?? 'N/A'); ?></td>
                                <td><?php echo e($request->reviewed_by ? optional(\App\Models\User::find($request->reviewed_by))->full_name : 'Not Checked'); ?>

                                </td>
                                <td><?php echo e($request->approved_by ? optional(\App\Models\User::find($request->approved_by))->full_name : 'Not Approved'); ?>

                                </td>
                                <td><?php echo e($request->created_at->format('Y-m-d H:i:s')); ?></td>
                                <td><?php echo e($request->updated_at->format('Y-m-d H:i:s')); ?></td>
                                <td>
                                    <a href="<?php echo e(route('payment-requests.downloadPdf', $request)); ?>" class="btn btn-info">
                                        <i class="bi bi-download"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Optional: Add Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

    <!-- Custom CSS for hover effects -->
    <style>
        .table-hover tr:hover {
            background-color: #f8f9fa;
            /* Light grey on hover */
            cursor: pointer;
            /* Pointer cursor on hover */
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/display/payment.blade.php ENDPATH**/ ?>