

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row mb-4">
            <div class="col-md-12 mt-5"> <!-- Added mt-5 for top margin -->
                <h1 class="text-center text-primary">Welcome to <?php echo e(Auth::user()->company->company_name); ?></h1>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-6 col-lg-4">
                <div class="card text-bg-success shadow-sm">
                    <i class="fas fa-user-shield fa-2x me-3"></i>
                    <div class="card-body">
                        <h5 class="card-title">Total Users</h5>
                        <p class="card-text fs-1"><?php echo e($totalUsers); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-4">
            <h2 class="text-secondary"><?php echo e(Auth::user()->full_name); ?> Manage Users</h2>
            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary mb-3">Create User</a>
            <div class="table-responsive">
                <table class="table table-bordered table-hover table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>Profile Image</th> <!-- New column for profile image -->
                            <th>Username</th>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Company ID</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if($user->profile_image): ?>
                                        <img src="<?php echo e(asset('storage/' . $user->profile_image)); ?>" alt="Profile Image"
                                            class="img-thumbnail" style="width: 50px; height: 50px;">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('path/to/default/image.png')); ?>" alt="Default Image"
                                            class="img-thumbnail" style="width: 50px; height: 50px;">
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($user->username); ?></td>
                                <td><?php echo e($user->full_name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->role); ?></td>
                                <td><?php echo e($user->company_id); ?></td>
                                <td>
                                    <a href="<?php echo e(route('users.edit', $user->user_id)); ?>"
                                        class="btn btn-warning btn-sm">Edit</a>
                                    <form action="<?php echo e(route('users.destroy', $user->user_id)); ?>" method="POST"
                                        class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm"
                                            onclick="return confirm('Are you sure you want to delete this user?');">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/users/index.blade.php ENDPATH**/ ?>