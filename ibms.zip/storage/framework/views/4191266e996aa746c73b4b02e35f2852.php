
<?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/components/application-logo.blade.php ENDPATH**/ ?>