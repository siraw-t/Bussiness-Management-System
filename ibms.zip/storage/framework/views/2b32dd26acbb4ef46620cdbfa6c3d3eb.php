



<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h2 class="mb-4">Inventory List</h2>
    <div class="table-responsive"> <!-- Make the table responsive -->
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Item Name</th>
                    <th>Quantity</th>
                    <th>Description</th>
                    <th>Stock In Date</th>
                    <th>Stock Out Date</th>
                    <th>Approved By</th>
                    <th>Managed By</th>
                    <th>Created At</th>
                    <th>Updated At</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    // Assuming the inventories collection is available in the view
                    $userId = auth()->id(); // Get the logged-in user's ID
                    $filteredInventories = $inventories->filter(function ($inventory) use ($userId) {
                        return $inventory->managed_by == $userId || $inventory->approved_by == $userId; // Adjust as necessary
                    });
                ?>

                <?php if($filteredInventories->isEmpty()): ?>
                    <tr>
                        <td colspan="9" class="text-center">No inventory items found.</td>
                    </tr>
                <?php else: ?>
                    <?php $__currentLoopData = $filteredInventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($inventory->item_name); ?></td>
                        <td><?php echo e($inventory->quantity); ?></td>
                        <td><?php echo e($inventory->description); ?></td>
                        <td><?php echo e($inventory->stock_in_date); ?></td>
                        <td><?php echo e($inventory->stock_out_date); ?></td>
                        <td>
                            <?php if($inventory->approved_by): ?>
                                <?php echo e(optional(\App\Models\User::find($inventory->approved_by))->full_name ?? 'N/A'); ?>

                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($inventory->managed_by): ?>
                                <?php echo e(optional(\App\Models\User::find($inventory->managed_by))->full_name ?? 'N/A'); ?>

                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($inventory->created_at->format('Y-m-d H:i:s')); ?></td>
                        <td><?php echo e($inventory->updated_at->format('Y-m-d H:i:s')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/displayinventory/index.blade.php ENDPATH**/ ?>