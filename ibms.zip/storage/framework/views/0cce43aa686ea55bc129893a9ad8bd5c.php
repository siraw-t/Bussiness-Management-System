

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="text-center text-primary mb-4"><?php echo e(Auth::user()->full_name); ?>'s Archived Documents</h1>

        <div class="text-center mb-4">
            <a href="<?php echo e(route('documents.create')); ?>" class="btn btn-primary mb-3 ">
                <i class="bi bi-file-earmark-plus "></i> Add New Document
            </a>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table class="table table-striped table-hover">
            <thead class="thead-dark">
                <tr>
                    <th>Document Name</th>
                    <th>Document Type</th>
                    <th>Description</th>
                    <th>Owner</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($document->document_name); ?></td>
                        <td><?php echo e($document->document_type); ?></td>
                        <td><?php echo e($document->description); ?></td>
                        <td><?php echo e($document->owner->username); ?></td>
                        <td>
                            <a href="<?php echo e(route('documents.show', $document)); ?>" class="btn btn-info btn-sm">
                                <i class="bi bi-eye"></i> View
                            </a>
                            <a href="<?php echo e(route('documents.edit', $document)); ?>" class="btn btn-warning btn-sm">
                                <i class="bi bi-pencil"></i> Edit
                            </a>
                            <form action="<?php echo e(route('documents.destroy', $document)); ?>" method="POST"
                                style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm"
                                    onclick="return confirm('Are you sure you want to delete this document?');">
                                    <i class="bi bi-trash"></i> Delete
                                </button>
                            </form>
                            <?php if($document->pdf_path): ?>
                                <a href="<?php echo e(route('documents.generate', $document)); ?>" class="btn btn-success btn-sm">
                                    <i class="bi bi-file-earmark-arrow-down"></i> Download PDF
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <style>
        .table-hover tr:hover {
            background-color: #f8f9fa;
            /* Light grey on hover */
            cursor: pointer;
            /* Pointer cursor on hover */
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/documents/index.blade.php ENDPATH**/ ?>