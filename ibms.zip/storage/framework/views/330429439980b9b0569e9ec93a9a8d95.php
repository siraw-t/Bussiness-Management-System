<!DOCTYPE html>
<html>
<head>
    <title>Leave Request</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
        }
        h1 {
            text-align: center;
        }
        .details {
            margin: 20px;
        }
    </style>
</head>
<body>
    <h1>Leave Request</h1>
    <div class="details">
        <p><strong>Employee ID:</strong> <?php echo e($data['user_id']); ?></p>
        <p><strong>Start Date:</strong> <?php echo e($data['start_date']); ?></p>
        <p><strong>End Date:</strong> <?php echo e($data['end_date']); ?></p>
        <p><strong>Reason:</strong> <?php echo e($data['reason']); ?></p>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/leave_request.blade.php ENDPATH**/ ?>