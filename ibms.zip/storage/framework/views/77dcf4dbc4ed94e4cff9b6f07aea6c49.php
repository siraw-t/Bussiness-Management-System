



<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-5">
        <h2 class="text-center text-primary mb-4">Leave Requests</h2>

        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover">
                <thead class="thead-dark">
                    <tr>
                        <th>Full Name</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Leave Type</th>
                        <th>Other Reason</th>
                        <th>Employee Signature</th>
                        <th>Uploaded File</th>
                        <th>Status</th>
                        <th>Approved By</th>
                        <th>Manager Comments</th>
                        <th>Company Country</th>
                        <th>Reference Number</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(auth()->guard()->check()): ?>
                        <?php
                            $user = auth()->user();
                            $companyId = $user->company_id ?? null;

                            $filteredLeaveRequests = $companyId
                                ? $leaveRequests->filter(
                                    fn($request) => optional($request->user)->company_id == $companyId,
                                )
                                : collect();
                        ?>

                        <?php if($filteredLeaveRequests->isEmpty()): ?>
                            <tr>
                                <td colspan="15" class="text-center text-danger">No leave requests found.</td>
                            </tr>
                        <?php else: ?>
                            <?php $__currentLoopData = $filteredLeaveRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="align-middle">
                                    <td><?php echo e($request->employee->full_name ?? 'N/A'); ?></td>
                                    <td><?php echo e($request->start_date); ?></td>
                                    <td><?php echo e($request->end_date); ?></td>
                                    <td><?php echo e(ucfirst(str_replace('_', ' ', $request->leave_type))); ?></td>
                                    <td><?php echo e($request->other_reason ?? 'N/A'); ?></td>
                                    <td>
                                        <?php if($request->employee_signature): ?>
                                            <img src="<?php echo e(asset('storage/' . $request->employee_signature)); ?>" alt="Signature"
                                                style="width: 100px;">
                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($request->attachment): ?>
                                            <a href="<?php echo e(asset('storage/' . $request->attachment)); ?>" target="_blank">View
                                                File</a>
                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span
                                            class="badge <?php echo e($request->status === 'approved' ? 'bg-success' : ($request->status === 'pending' ? 'bg-warning' : 'bg-danger')); ?>">
                                            <?php echo e(ucfirst($request->status)); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e(optional(\App\Models\User::find($request->approved_by))->full_name ?? 'N/A'); ?></td>
                                    <td><?php echo e($request->manager_comments ?? 'N/A'); ?></td>
                                    <td><?php echo e($request->company_country); ?></td>
                                    <td><?php echo e($request->reference_number); ?></td>
                                    <td><?php echo e($request->created_at->format('Y-m-d H:i:s')); ?></td>
                                    <td><?php echo e($request->updated_at->format('Y-m-d H:i:s')); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('leave-requests.downloadPdf', $request)); ?>"
                                            class="btn btn-info">Download PDF</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="15" class="text-center">
                                <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">Please log in to view your leave
                                    requests.</a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Optional: Add Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

    <!-- Custom CSS for hover effects -->
    <style>
        .table-hover tr:hover {
            background-color: #f8f9fa;
            /* Light grey on hover */
            cursor: pointer;
            /* Pointer cursor on hover */
            transition: background-color 0.3s;
            /* Smooth transition */
        }

        .btn {
            transition: transform 0.2s;
        }

        .btn:hover {
            transform: scale(1.05);
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/display/leave.blade.php ENDPATH**/ ?>