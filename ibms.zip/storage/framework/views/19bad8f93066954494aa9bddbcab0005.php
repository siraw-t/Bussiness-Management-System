

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="text-center text-warning mb-4"><i class="fas fa-edit"></i> Edit Inventory Item</h1>

        <form action="<?php echo e(route('inventory.update', $inventory->inventory_id)); ?>" method="POST"
            class="shadow p-4 rounded bg-light" style="max-width: 500px; margin: auto;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group mb-3">
                <label for="item_name">Item Name</label>
                <input type="text" name="item_name" class="form-control" value="<?php echo e($inventory->item_name); ?>" required>
            </div>
            <div class="form-group mb-3">
                <label for="tag_number">Tag Number</label>
                <input type="text" name="tag_number" class="form-control" value="<?php echo e($inventory->tag_number); ?>"
                    placeholder="Optional">
            </div>
            <div class="form-group mb-3">
                <label for="item_type">Item Type</label>
                <select name="item_type" class="form-control" required>
                    <option value="fixed asset" <?php echo e($inventory->item_type == 'fixed asset' ? 'selected' : ''); ?>>
                        Fixed Asset
                    </option>
                    <option value="consumable" <?php echo e($inventory->item_type == 'consumable' ? 'selected' : ''); ?>>
                        Consumable
                    </option>
                </select>
            </div>
            
            <div class="form-group mb-3">
                <label for="quantity">Quantity</label>
                <input type="number" name="quantity" class="form-control" value="<?php echo e($inventory->quantity); ?>" required
                    min="0">
            </div>
            <div class="form-group mb-3">
                <label for="unit_price">Unit Price</label>
                <input type="number" name="unit_price" class="form-control" value="<?php echo e($inventory->unit_price); ?>" required
                    step="0.01" min="0">
            </div>
            <div class="form-group mb-3">
                <label for="description">Description</label>
                <textarea name="description" class="form-control"><?php echo e($inventory->description); ?></textarea>
            </div>
            <div class="form-group mb-3">
                <label for="stock_in_date">Stock In Date</label>
                <input type="date" name="stock_in_date" class="form-control" value="<?php echo e($inventory->stock_in_date); ?>">
            </div>
            <div class="form-group mb-3">
                <label for="currency">Currency</label>
                <select name="currency" class="form-control" required>
                    <option value="USD" <?php echo e($inventory->currency == 'USD' ? 'selected' : ''); ?>>USD</option>
                    <option value="EUR" <?php echo e($inventory->currency == 'EUR' ? 'selected' : ''); ?>>EUR</option>
                    <option value="UGX" <?php echo e($inventory->currency == 'UGX' ? 'selected' : ''); ?>>UGX</option>
                    <option value="ETB" <?php echo e($inventory->currency == 'ETB' ? 'selected' : ''); ?>>ETB</option>
                    <option value="AUD" <?php echo e($inventory->currency == 'AUD' ? 'selected' : ''); ?>>AUD</option>
                    <!-- Add more currencies as needed -->
                </select>
            </div>
            <div class="form-group mb-3">
                <label for="unit">Unit</label>
                <select name="unit" class="form-control" required>
                    <option value="pcs" <?php echo e($inventory->unit == 'pcs' ? 'selected' : ''); ?>>Pieces</option>
                    <option value="kg" <?php echo e($inventory->unit == 'kg' ? 'selected' : ''); ?>>Kilograms</option>
                    <option value="liters" <?php echo e($inventory->unit == 'liters' ? 'selected' : ''); ?>>Liters</option>
                    <option value="m" <?php echo e($inventory->unit == 'm' ? 'selected' : ''); ?>>Meters</option>
                    <option value="box" <?php echo e($inventory->unit == 'box' ? 'selected' : ''); ?>>Boxes</option>
                    <!-- Add more units as needed -->
                </select>
            </div>
            
            <button type="submit" class="btn btn-warning w-100">
                <i class="fas fa-sync-alt"></i> Update Item
            </button>
            <a href="<?php echo e(route('inventory.index')); ?>" class="btn btn-secondary w-100 mt-2">
                <i class="fas fa-times-circle"></i> Cancel
            </a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/inventory/edit.blade.php ENDPATH**/ ?>