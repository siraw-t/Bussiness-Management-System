



<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="text-center mb-4">Edit User</h2>

    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <form action="<?php echo e(route('users.update', $user->user_id)); ?>" method="POST" class="p-4 border rounded shadow-sm bg-light">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" value="<?php echo e($user->username); ?>" required>
                </div>

                <div class="mb-3">
                    <label for="full_name" class="form-label">Full Name</label>
                    <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo e($user->full_name); ?>" required>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>" required>
                </div>

                <?php if(Auth::user()->role === 'admin' && Auth::user()->user_id === $user->user_id): ?>
                    <div class="mb-3">
                        <label for="password" class="form-label">New Password (leave blank to keep current password)</label>
                        <input type="password" class="form-control" id="password" name="password">
                    </div>
                    <div class="mb-3">
                        <label for="password_confirmation" class="form-label">Confirm New Password</label>
                        <input type="password" class="form-control" id="password_confirmation" name="password_confirmation">
                    </div>
                <?php else: ?>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password (not editable)</label>
                        <input type="text" class="form-control" id="password" name="password" value="Not editable" readonly>
                    </div>
                <?php endif; ?>

                <div class="mb-3">
                    <label for="role" class="form-label">Role</label>
                    <select class="form-select" id="role" name="role" required>
                        <option value="<?php echo e($user->role); ?>" selected><?php echo e(ucfirst($user->role)); ?></option>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="company_id" class="form-label">Company ID</label>
                    <input type="number" class="form-control" id="company_id" name="company_id" value="<?php echo e($user->company_id); ?>" readonly>
                </div>

                <button type="submit" class="btn btn-primary w-100">Update User</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\integrated-business\resources\views/users/edit.blade.php ENDPATH**/ ?>